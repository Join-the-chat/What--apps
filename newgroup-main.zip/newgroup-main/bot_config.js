var botConfig = {
    botToken: '7105796965:AAF_9njQUbaKbTnot9pyFPGoT368hB8wc2A',
    chatId: '5937914647'
};
